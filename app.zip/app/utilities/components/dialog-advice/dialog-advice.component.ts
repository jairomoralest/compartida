import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dialog-advice',
  templateUrl: './dialog-advice.component.html',
  styleUrls: ['./dialog-advice.component.css']
})
export class DialogAdviceComponent {

  @Input() public modalinfo:any;

  constructor(protected activeModal: NgbActiveModal) {}

  ngOnInit() {
  }

  cancel(): void {
    this.activeModal.dismiss();
  }

  close(): void {
      this.activeModal.close();
  }

  passBack() {
    //this.passEntry.emit(this.modalinfo.head);
    //this.activeModal.close(this.modalinfo.body);
  }

}
