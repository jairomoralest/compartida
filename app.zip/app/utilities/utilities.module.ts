import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UtilitiesRoutingModule } from './utilities-routing.module';
import { DialogComponent } from './components/dialog/dialog.component';
import { DialogErrorComponent } from './components/dialog-error/dialog-error.component';
import { DialogAdviceComponent } from './components/dialog-advice/dialog-advice.component';

@NgModule({
  declarations: [
    DialogComponent,
    DialogErrorComponent,
    DialogAdviceComponent
  ],
  imports: [
    CommonModule,
    UtilitiesRoutingModule
  ]
})
export class UtilitiesModule { }
