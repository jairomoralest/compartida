import { Injectable } from '@angular/core';

import {Router} from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { finalize,Observable, catchError, throwError } from 'rxjs';
import {  HttpRequest,  HttpHandler,  HttpEvent,  HttpInterceptor,  HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class InterceptorsInterceptor implements HttpInterceptor {

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const token = localStorage.getItem('token');
    if (token) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    }
    return next.handle(request);
  }

}
