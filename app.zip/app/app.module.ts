import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { InterceptorsInterceptor } from './interceptors/interceptors.interceptor';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { AdministradorModule } from './administrador/administrador.module';
import { AdministradorRoutingModule } from './administrador/administrador-routing.module';
import { TramiteRoutingModule } from './tramite/tramite-routing.module';
import { TramiteModule } from './tramite/tramite.module';
import { RegistersModule } from './registers/registers.module';
import { RegistersRoutingModule } from './registers/registers-routing.module';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoginComponent } from './components/login/login.component';
import { RecepcionModule } from './recepcion/recepcion.module';
import { RecepcionRoutingModule } from './recepcion/recepcion-routing.module';
import { ContratistaModule } from './contratista/contratista.module';
import { ContratistaRoutingModule } from './contratista/contratista-routing.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { DashboardRoutingModule } from './dashboard/dashboard-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule,
    BrowserAnimationsModule,
    NgbDatepickerModule,
    AdministradorModule,
    AdministradorRoutingModule,
    RegistersModule,
    RegistersRoutingModule,
    TramiteModule,
    TramiteRoutingModule,
    RecepcionModule,
    RecepcionRoutingModule,
    ContratistaModule,
    ContratistaRoutingModule,
    DashboardModule,
    DashboardRoutingModule,
    NgxUiLoaderModule.forRoot({
    "bgsColor": "red",
    "fgsColor": "#BFC9D7",
    "fgsType": "three-strings",
    "overlayColor": "rgba(0, 0, 0, 0)",
    "minTime": 200}),
  ],
  providers: [{
    provide:HTTP_INTERCEPTORS,
    useClass:InterceptorsInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
