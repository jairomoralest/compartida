import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthenticateGuard } from './guard/authenticate.guard';
import { ExternoGuard } from './guard/externo.guard';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoginComponent } from './components/login/login.component';

const routes: Routes = [
  {
    path:'navbar',
    component :NavbarComponent,
    canActivate:[AuthenticateGuard,ExternoGuard]
  },
  {
    path:'',
    component :LoginComponent
  },
  {
    path:'login',
    component :LoginComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule {

}
