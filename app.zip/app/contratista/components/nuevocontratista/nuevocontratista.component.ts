import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BackendService } from 'src/app/services/backend.service';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { NgxUiLoaderService } from 'ngx-ui-loader';

@Component({
  selector: 'app-nuevocontratista',
  templateUrl: './nuevocontratista.component.html',
  styleUrls: ['./nuevocontratista.component.css']
})
export class NuevocontratistaComponent implements OnInit {


  arbol_tramite='';
  arbol_expediente='';

  idExpediente='';
  estadoDocumento=false;
  public showtramiteEstado:boolean=false;
  public tramiteEstado:boolean=false;

  btn_ticketPDF:boolean=false;
  btn_sendEmailCiudadano:boolean=false;

  btn_newDocumento:boolean=true;
  cedulaLogueado:string='';
  btn_ticket:boolean = true;
  btn_desmaterializa:boolean = true;
  btn_enviaremail:boolean = true;

  // datos tramite
  public idTramite='';
  public fechaIngresoTramite='';
  public horaIngresoTramite='';

  login_usua_nomb='';
  login_usua_apellido='';

  page: number = 1;
  count: number = 0;
  tableSize: number = 7;
  tableSizes: any = [3, 6, 9, 12];

  shownavbar=true;
  list_tble_tecnico:any;
  list_tble_categoria:any;

  public list_bg_obra:any;
  public selectedIDTecnico:any;
  public selectedIDCategoria:any;
  public selectedIDObra:any;

  public formfillDocumento = {
    fecha:"",
    asunto:"",
    descripcion:"",
    expediente:"",
    tramite:""
  }

  nowDate: string='';
  currentDay: string='';
  currentMonth: string='';
  currentYear: string='';
  currentHour: string='';
  currentMinut: string='';
  currentSecon: string='';

  public formSelContratista = {
    ciu_ruc:'',
    ciu_nombre:'',
    ciu_apellido:'',
    ciu_telefono:'',
    ciu_email:'',
    ciu_organizacion:'',
    ciu_cargo:'',
    ciu_tipo_usuario:'',
  }

  public formSelAdministrador = {
    usua_cedula:'',
    usua_nomb:'',
    usua_apellido:'',
    usua_telefono:'',
    usua_email:'',
    usua_cargo:'',
    usu_departamento:''
  }

  public formSelFiscalizador = {
    usua_cedula:'',
    usua_nomb:'',
    usua_apellido:'',
    usua_telefono:'',
    usua_email:'',
    usua_cargo:'',
    usu_departamento:''
  }

  public objCategoria = {
    id_cat:'',
    nom_cat:''
  }

  /*Objeto del tecnico -> tabla migra*/
  public objTecnico = {
    usua_cargo:'',
    usua_cedula:'',
    usu_departamento:'',
    usua_nomb:'',
    usua_apellido:'',
    usua_nombrecompleto:'',
    usua_email:''
  }

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  selectFisico='FIS';
  selectTipo='TIP';

  public obj_arbol = {
    arbol_cod_ccd_u: '',
    arbol_codi_barras: '',
    arbol_secuencial:'',
    arbol_anio:'',
    arbol_nummemorado:'',
    arbol_id_tramite:'',
    arbol_usua_cedula_login:'',
    arbol_usua_nomb_login:'',
    arbol_usua_apellido_login:'',
    arbol_exp_num_exp:''
  }

  arrayPdf= new Array();

  filestramite:any;
  @ViewChild('fileInputRefTramite') fileInputRefTramite!: ElementRef<HTMLInputElement>;
  public myArrayFilestramite:any = [];
  duplicateFiles: string[] = [];
  sumFileSize: number = 0;

  constructor(private modalService:NgbModal,private backend: BackendService,private ngxService: NgxUiLoaderService){  }

  ngOnInit() {
    if(localStorage.getItem('tipo_usuario')=='CONTRATISTA'){
      this.backend.getList_tble_bg_obra(localStorage.getItem('cedula')).subscribe((listaobra:any) => {
        if(listaobra.status===true){
          this.list_bg_obra=listaobra.list;
        }
        else{
          this.showModalError('El contratista no tiene obras asignadas.');
        }
      });

      if(localStorage.getItem('token')!==null){
        const currentDate = new Date();
        this.currentDay = currentDate.getDate().toString();
        this.currentMonth = (currentDate.getMonth() + 1).toString();
        this.currentYear = currentDate.getFullYear().toString();
        this.currentHour= currentDate.getHours().toString();
        this.currentMinut= currentDate.getMinutes().toString();
        this.currentSecon= currentDate.getSeconds().toString();
        this.formfillDocumento.fecha=this.currentDay+'/'+this.currentMonth+'/'+this.currentYear+' '+this.currentHour+':'+this.currentMinut+':'+this.currentSecon;
        this.cedulaLogueado=String(localStorage.getItem('cedula'));
        this.login_usua_nomb=String(localStorage.getItem('nombres'));
        this.login_usua_apellido=String(localStorage.getItem('apellidos'));

        this.formSelContratista.ciu_ruc=String(localStorage.getItem('cedula'));
        this.formSelContratista.ciu_nombre=String(localStorage.getItem('nombres'));
        this.formSelContratista.ciu_apellido=String(localStorage.getItem('apellidos'));
        this.formSelContratista.ciu_telefono=String(localStorage.getItem('telefono'));
        this.formSelContratista.ciu_email=String(localStorage.getItem('email'));
        this.formSelContratista.ciu_organizacion=String(localStorage.getItem('organizacion'));
        this.formSelContratista.ciu_cargo=String(localStorage.getItem('cargo'));
        this.formSelContratista.ciu_tipo_usuario=String(localStorage.getItem('tipo_usuario'));

        this.loadData();
      }else{
        this.showModalError('La Cédula ha expirado!');
      }
    }else{
      this.showModalError('Este módulo está destinado a usuarios de tipo CONTRATISTA.');
    }
  }

  loadData():void {
    this.backend.getList_tble_recep_doc_tecnico_migra().subscribe((response:any) => {
      if(response.status){
        this.list_tble_tecnico=response.list;
        if (this.list_tble_tecnico.length > 0) {
          this.selectedIDTecnico = this.list_tble_tecnico[0].id;          ;
        } else {
          this.selectedIDTecnico = null;
        }
      }else{
        this.list_tble_tecnico=[];
        this.showModalError('No existen Técnicos para mostrar.');
      }
    });

    this.backend.getList_tble_categoria().subscribe((response:any) => {
      if(response.status){
        this.list_tble_categoria=response.list;
      }else{
        this.list_tble_categoria=[];
        this.showModalError('No existen Categorias para mostrar.');
      }
    });
  }

  onChangebgObras(event:any):void {
    this.ngxService.start();
    if(event!==undefined){
      this.backend.getObj_Obra_by_Id_adminFiscalContrato(event.id_admin).subscribe((objAdministrador:any)=>{
        if(objAdministrador.status==true){
          this.ngxService.stop();
          this.formfillDocumento.tramite=event.tramite;
          this.formfillDocumento.expediente=event.expediente;
          this.formSelAdministrador.usua_cedula=objAdministrador.list.usua_cedula;
          this.formSelAdministrador.usua_nomb=objAdministrador.list.usua_nomb;
          this.formSelAdministrador.usua_apellido=objAdministrador.list.usua_apellido;
          this.formSelAdministrador.usua_telefono=objAdministrador.list.usua_telefono;
          this.formSelAdministrador.usua_email=objAdministrador.list.usua_email;
          this.formSelAdministrador.usua_cargo=objAdministrador.list.usua_cargo;
          this.formSelAdministrador.usu_departamento=objAdministrador.list.usu_departamento;
          this.backend.getObj_Obra_by_Id_adminFiscalContrato(event.id_fiscalizador).subscribe((objFiscalizador:any)=>{
            if(objFiscalizador.status==true){
              this.ngxService.stop();
              this.formSelFiscalizador.usua_cedula=objFiscalizador.list.usua_cedula;
              this.formSelFiscalizador.usua_nomb=objFiscalizador.list.usua_nomb;
              this.formSelFiscalizador.usua_apellido=objFiscalizador.list.usua_apellido;
              this.formSelFiscalizador.usua_telefono=objFiscalizador.list.usua_telefono;
              this.formSelFiscalizador.usua_email=objFiscalizador.list.usua_email;
              this.formSelFiscalizador.usua_cargo=objFiscalizador.list.usua_cargo;
              this.formSelFiscalizador.usu_departamento=objFiscalizador.list.usu_departamento;
            }else{
              this.formSelFiscalizador.usua_cedula="";
              this.formSelFiscalizador.usua_nomb="";
              this.formSelFiscalizador.usua_apellido="";
              this.formSelFiscalizador.usua_telefono="";
              this.formSelFiscalizador.usua_email="";
              this.formSelFiscalizador.usua_cargo="";
              this.formSelFiscalizador.usu_departamento="";
              this.showModalError('La Obra no tiene un fiscalizador');
            }
          });
        }else{
          this.ngxService.stop();
          this.formSelAdministrador.usua_cedula="";
          this.formSelAdministrador.usua_nomb="";
          this.formSelAdministrador.usua_apellido="";
          this.formSelAdministrador.usua_telefono="";
          this.formSelAdministrador.usua_email="";
          this.formSelAdministrador.usua_cargo="";
          this.formSelAdministrador.usu_departamento="";

          this.formSelFiscalizador.usua_cedula="";
          this.formSelFiscalizador.usua_nomb="";
          this.formSelFiscalizador.usua_apellido="";
          this.formSelFiscalizador.usua_telefono="";
          this.formSelFiscalizador.usua_email="";
          this.formSelFiscalizador.usua_cargo="";
          this.formSelFiscalizador.usu_departamento="";
          this.showModalError('La Obra no tiene un administrador');
        }
      });
    }

    this.arbol_tramite=event.tramite;
    this.arbol_expediente=event.expediente;

    this.backend.getTramitesFilesListPDFById(this.arbol_tramite,this.arbol_expediente).subscribe((data:any)=>{
      if(data.status){
        this.arrayPdf=data.listFiles
      }else{
        this.showModalError("Error al cargar los archivos PDF, consultar al administrador del Sitio");
      }
    });

  }

  onChangeFisicoList(event:any):void {
    if(event!==undefined){
      //this.nombreFuente=event.nombre;
      //console.log(event.nombre);
    }
  }

  onChangeTipoList(event:any):void {
    if(event!==undefined){
      //console.log(event);
    }
  }

  onChangeTecnicoList(event:any):void {
    //console.log(event);
  }

  redirectNewTramite():void {
  }

  onDragOverTramite(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
  }

  onDropTramite(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    const files = event.dataTransfer?.files;
    if (files) {
      this.handleFilesTramite(files);
    }
  }

  handleFilesTramite(files: FileList | null) {
    if (files) {
      this.duplicateFiles = [];
      for (let i = 0; i < files.length; i++) {
        var file = files[i];
        var fileNameExists = this.myArrayFilestramite.some((f: any) => f.name === file.name);
        if (fileNameExists) {
          this.duplicateFiles.push(file.name);
        } else if (file.type === 'application/pdf' && file.size <= 52428800) {
          this.myArrayFilestramite.push(file);
        } else {
          this.showModalError('Debe cargar un documento en formato PDF, con un peso inferior a 50 MB');
        }
      }
      if (this.duplicateFiles.length === 1) {
        this.showModalError(`El archivo ${this.duplicateFiles.join(', ')}, ya se ha ingresado.`);
      }else if (this.duplicateFiles.length > 1) {
        this.showModalError(`Existen archivos que ya se han ingresado: ${this.duplicateFiles.join(', ')}`);
      }
    }
  }

  onFilesSelectedTramite(event: Event): void {
    this.filestramite = (event.target as HTMLInputElement).files;
    if (this.filestramite) {
      this.duplicateFiles = [];
      for (let i = 0; i < this.filestramite.length; i++) {
        var file = this.filestramite[i];
        var fileNameExists = this.myArrayFilestramite.some((f: any) => f.name === file.name);
        if (fileNameExists) {
          this.duplicateFiles.push(file.name);
        } else if (file.type === 'application/pdf' && file.size <= 52428800) {
          this.myArrayFilestramite.push(file);
        } else {
          this.showModalError('Debe cargar un documento en formato PDF, con un peso inferior a 50 MB');
        }
      }
      if (this.duplicateFiles.length === 1) {
        this.showModalError(`El archivo ${this.duplicateFiles.join(', ')}, ya se ha ingresado.`);
      }else if (this.duplicateFiles.length > 1) {
        this.showModalError(`Existen archivos que ya se han ingresado: ${this.duplicateFiles.join(', ')}`);
      }
    }
  }

  deleteFileContratista(index: number): void {
    this.myArrayFilestramite.splice(index, 1);
  }

  formatBytesToMB(bytes:number, decimals = 2) {
    if (bytes === 0)
      return '0 MB';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const mb = bytes / Math.pow(k, 2);
    return `${parseFloat(mb.toFixed(dm))} MB`;
  }

  onTableDataChange(event: any) {
    this.page = event;
  }

  closeModal(){
    //this.modalService. .close();
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  statefile=true;
  saveDocumento():void {
    this.ngxService.start();
    this.sumFileSize=0;
    for(var i=0; i<this.myArrayFilestramite.length;i++) {
      this.sumFileSize+=parseFloat(this.myArrayFilestramite[i].size);
    }
    const valorMB=parseFloat(this.formatBytesToMB(this.sumFileSize, 2));

    for(var i=0; i<this.myArrayFilestramite.length;i++) {
       for(var j=0; j<this.arrayPdf.length;j++){
        if(this.myArrayFilestramite[i].name===this.arrayPdf[j].name.slice(8)+'.'+this.arrayPdf[j].extension){
          this.statefile=false;
          this.showModalError('El documento con el nombre "' + this.arrayPdf[j].name.slice(8)+'.'+this.arrayPdf[j].extension + '" ya está registrado y no se puede subir nuevamente.');
          this.ngxService.stop();
          return;
        }
       }
    }

    if(valorMB <= 50) {
      const objJson = {
        objCategoria:this.objCategoria,
        objTecnico:this.objTecnico,
        formfillDocumento:this.formfillDocumento,      // agregar varios
        selectedIDTecnico:this.selectedIDTecnico,      // agregar tecnico
        selectedIDObra:this.selectedIDObra,            // agregar tecnico
        objContratista:this.formSelAdministrador,      // Administrador
        objFiscalizador:this.formSelFiscalizador,      // Fiscalizador
        formSelContratista:this.formSelContratista,    // Contratista
      }
      if(this.formfillDocumento.tramite!=""){
        if(this.formfillDocumento.expediente!=""){
          if(this.formfillDocumento.fecha!=""){
            if(this.formfillDocumento.descripcion!=""){
              if(this.formSelFiscalizador.usua_cedula!=""){
                if(this.formSelFiscalizador.usua_nomb!=""){
                  if(this.formSelFiscalizador.usua_apellido!=""){
                    if(this.formSelContratista.ciu_ruc!=""){
                      if(this.formSelContratista.ciu_nombre!=""){
                        if(this.formSelContratista.ciu_apellido!=""){
                          if(this.formSelAdministrador.usua_cedula!=""){
                            if(this.formSelAdministrador.usua_nomb!=""){
                              if(this.formSelAdministrador.usua_apellido!=""){
                                  this.backend.create_obra_contratista(objJson,this.myArrayFilestramite).subscribe((data:any)=>{
                                    if(data.status){
                                      this.ngxService.stop();
                                      this.btn_ticketPDF=true;
                                      this.btn_sendEmailCiudadano=true;
                                      this.btn_newDocumento=true;
                                      this.idExpediente=data.idExpediente;  //
                                      this.idTramite=data.idTramite;        //
                                      this.fechaIngresoTramite=data.fechaIngresoTramite;
                                      this.horaIngresoTramite=data.horaIngresoTramite;
                                      this.showtramiteEstado=true;
                                      this.tramiteEstado=true;
                                      this.estadoDocumento=true;
                                      if(data.estadoDocumento=='activo'){
                                        this.showModal('La Obra-Contratista '+this.idTramite+', y sus anexos se han almacenado con éxito.');
                                      }else if(data.estadoDocumento=='bloqueado'){
                                        this.showModal('La Obra-Contratista '+this.idTramite+', se ha guardado.<BR> Sus anexos no se han almacenado con éxito.');
                                      } else if(data.estadoDocumento=='inactivo'){
                                        this.showModal('La Obra-Contratista '+this.idTramite+', se guardado con éxito.');
                                      }
                                    } else{
                                      this.ngxService.stop();
                                      this.showModalError('Debe agregar el número de páginas');
                                    }
                                  },
                                  (error: any) => {
                                    this.ngxService.stop();
                                    this.showModalError('Ocurrió un error al intentar almacenar los anexos. Por favor, inténtelo de nuevo más tarde, Verifique el peso de los archivos PDF');
                                  });

                              }else{
                                this.ngxService.stop();
                                this.showModalError('Debe agregar el apellido del Administrador');
                              }
                            }else{
                              this.ngxService.stop();
                              this.showModalError('Debe agregar el nombre del Administrador');
                            }
                          }else{
                            this.ngxService.stop();
                            this.showModalError('Debe agregar la cédula del Administrador');
                          }
                        }else{
                          this.ngxService.stop();
                          this.showModalError('Debe agregar el apellido del Contratista');
                        }
                      }else{
                        this.ngxService.stop();
                        this.showModalError('Debe agregar el nombre del Contratista');
                      }
                    }else{
                      this.ngxService.stop();
                      this.showModalError('Debe agregar la cédula del Contratista');
                    }
                  }else{
                    this.ngxService.stop();
                    this.showModalError('Debe agregar el apellido del Fiscalizador');
                  }
                }else{
                  this.ngxService.stop();
                  this.showModalError('Debe agregar el nombre del Fiscalizador');
                }
              }else{
                this.ngxService.stop();
                this.showModalError('Debe agregar la cédula del Fiscalizador');
              }
            }else{
              this.ngxService.stop();
              this.showModalError('Debe agregar una descripción');
            }
          }else{
            this.ngxService.stop();
            this.showModalError('Debe agregar una fecha');
          }
        }else{
          this.ngxService.stop();
          this.showModalError('No existe un expediente');
        }
      }else{
        this.ngxService.stop();
        this.showModalError('No existe un número de trámite');
      }
    }else{
      this.ngxService.stop();
      this.showModalError('Los archivos tienen un peso total de : '+valorMB+' MB , y no deben exeder los 50 MB');
    }
  }

  sendEmailAdminContraFiscal():void{
    this.ngxService.start();
    if(this.formSelContratista.ciu_email!="") {
        const objetoContratista = {
          idExpediente:this.idExpediente,
          tipo:'Tramite',
          idTramite:this.idTramite,
          nomTramite:this.formfillDocumento.asunto,
          nomCiudadano:this.formSelContratista.ciu_nombre+' '+this.formSelContratista.ciu_apellido,
          fechaIngresoTramite:this.fechaIngresoTramite,
          horaIngresoTramite:this.horaIngresoTramite,
          correo:this.formSelContratista.ciu_email
        }

        this.backend.sendEmailTramite_to_Ciudadano(objetoContratista).subscribe((resContratista:any) => {
          if(resContratista.status){
            this.btn_newDocumento=false;
              if(this.formSelAdministrador.usua_email!="") {
                  const objetoAdministrador = {
                    idExpediente:this.idExpediente,
                    tipo:'Tramite',
                    idTramite:this.idTramite,
                    nomTramite:this.formfillDocumento.asunto,
                    nomCiudadano:this.formSelAdministrador.usua_nomb+' '+this.formSelAdministrador.usua_apellido,
                    fechaIngresoTramite:this.fechaIngresoTramite,
                    horaIngresoTramite:this.horaIngresoTramite,
                    correo:this.formSelAdministrador.usua_email
                  }
                  this.backend.sendEmailTramite_to_Ciudadano(objetoAdministrador).subscribe((resAmdinistrador:any) => {
                    if(resAmdinistrador.status){
                      this.btn_newDocumento=false;
                        if(this.formSelFiscalizador.usua_email!="") {
                            const objetoFiscaliza = {
                              idExpediente:this.idExpediente,
                              tipo:'Tramite',
                              idTramite:this.idTramite,
                              nomTramite:this.formfillDocumento.asunto,
                              nomCiudadano:this.formSelFiscalizador.usua_nomb+' '+this.formSelFiscalizador.usua_apellido,
                              fechaIngresoTramite:this.fechaIngresoTramite,
                              horaIngresoTramite:this.horaIngresoTramite,
                              correo:this.formSelFiscalizador.usua_email
                            }
                            this.backend.sendEmailTramite_to_Ciudadano(objetoFiscaliza).subscribe((resFiscal:any) => {
                              if(resFiscal.status){
                                this.ngxService.stop();
                                this.btn_newDocumento=false;
                                this.showModal(
                                  'El email: ' + resContratista.email + ', se ha enviado hacia el Contratista.\n' +
                                  'El email: ' + resAmdinistrador.email + ', se ha enviado hacia el Administrador.\n' +
                                  'El email: ' + resFiscal.email + ', se ha enviado hacia el Fiscalizador.\n');
                              } else {
                                this.ngxService.stop();
                                this.showModalError('El email:'+resFiscal.email+', no se ha enviado hacia el Fiscalizador');
                              }
                            });
                        }else {
                          this.ngxService.stop();
                          this.showModalError('El Fiscalizador debe tener un email!');
                        }
                    } else {
                      this.ngxService.stop();
                      this.showModalError('El email:'+resAmdinistrador.email+', no se ha enviado hacia el Administrador');
                    }
                  });
              }else {
                this.ngxService.stop();
                this.showModalError('El Administrador debe tener un email!');
              }
          } else {
            this.ngxService.stop();
            this.showModalError('El email:'+resContratista.email+', no se ha enviado hacia el Contratista');
          }
        });
    }else {
      this.ngxService.stop();
      this.showModalError('El Contratista debe tener un email!');
    }
  }

  newDocumento():void {
    this.sumFileSize=0;
    this.selectedIDObra=null;
    this.selectedIDCategoria=null;

    this.idExpediente='';
    this.btn_ticketPDF=false;
    this.btn_sendEmailCiudadano=false;
    this.btn_newDocumento=false;

    this.formfillDocumento.asunto="";
    this.formfillDocumento.descripcion="";
    this.formfillDocumento.expediente="";
    this.formfillDocumento.tramite="";

    this.formSelAdministrador.usua_cedula="";
    this.formSelAdministrador.usua_nomb="";
    this.formSelAdministrador.usua_apellido="";
    this.formSelAdministrador.usua_telefono="";
    this.formSelAdministrador.usua_email="";
    this.formSelAdministrador.usua_cargo="";
    this.formSelAdministrador.usu_departamento="";

    this.formSelFiscalizador.usua_cedula="";
    this.formSelFiscalizador.usua_nomb="";
    this.formSelFiscalizador.usua_apellido="";
    this.formSelFiscalizador.usua_telefono="";
    this.formSelFiscalizador.usua_email="";
    this.formSelFiscalizador.usua_cargo="";
    this.formSelFiscalizador.usu_departamento="";

    this.selectedIDTecnico=null;
    this.myArrayFilestramite=[];
    this.tramiteEstado=false;
    this.showtramiteEstado=false;
  }

  keyPressNumbers(event:any) {
    var charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  keyPressCharacters(event: any) {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (!(charCode >= 65 && charCode <= 90) && // uppercase letters
        !(charCode >= 97 && charCode <= 122) && // lowercase letters
        charCode !== 32 && // space
        charCode !== 8 && // backspace
        charCode !== 9 && // tab
        charCode !== 46 // delete
    ) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  isNumeric(value: any): boolean {
    return !isNaN(parseFloat(value)) && isFinite(value);
  }

  isText(value: any): boolean {
    return typeof value === 'string';
  }

  addObjetoToListCategoria(event:any):void{
    if(event!=undefined){
      this.backend.getList_tble_bg_expendiende_ByID(event.id_cat).subscribe((response:any) => {
        if(response.status){
          this.objCategoria=response.list;
        }else{
        }
      });
    }else{
      this.selectedIDCategoria=null;
    }
  }

  addObjetoToListTecnicos(event:any):void{
    if(event!=undefined){
      this.backend.getList_tble_recep_doc_tecnico_migraByID(event.id).subscribe((response:any) => {
        if(response.status){
          this.objTecnico=response.list;
        }else{
        }
      });
    }else{
      this.selectedIDTecnico=null;
    }
  }

}
