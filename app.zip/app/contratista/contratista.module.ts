import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContratistaRoutingModule } from './contratista-routing.module';
import { NuevocontratistaComponent } from './components/nuevocontratista/nuevocontratista.component';
import { FormsModule } from '@angular/forms';           // ngForm OK
import { NgxPaginationModule } from 'ngx-pagination';   // pagination
import { NgSelectModule } from '@ng-select/ng-select';  // select OK

@NgModule({
  declarations: [
    NuevocontratistaComponent
  ],
  imports: [
    CommonModule,
    ContratistaRoutingModule,
    FormsModule,
    NgxPaginationModule,
    NgSelectModule
  ]
})
export class ContratistaModule { }
