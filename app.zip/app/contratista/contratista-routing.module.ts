import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NuevocontratistaComponent } from './components/nuevocontratista/nuevocontratista.component';
import { ExternoGuard } from '../guard/externo.guard';

const routes: Routes = [

  {
    path:'contratista',
    component :NuevocontratistaComponent,
    canActivate:[ExternoGuard]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContratistaRoutingModule { }
