import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TramiteRoutingModule } from './tramite-routing.module';
import { FormsModule } from '@angular/forms';           // ngForm OK
import { NgxPaginationModule } from 'ngx-pagination';   // pagination
import { NgSelectModule } from '@ng-select/ng-select';  // select OK
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SelecttramiteComponent } from './components/selecttramite/selecttramite.component';
import { NuevotramiteComponent } from './components/nuevotramite/nuevotramite.component';


@NgModule({
  declarations: [
    NuevotramiteComponent,
    SelecttramiteComponent
  ],
  imports: [
    CommonModule,
    TramiteRoutingModule,
    FormsModule,
    NgxPaginationModule,
    NgbModule,
    NgSelectModule
  ]
})
export class TramiteModule { }
