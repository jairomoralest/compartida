import { NgModule } from '@angular/core';
import { RouterModule, Routes, CanActivate } from '@angular/router';
import { ExternoGuard } from '../guard/externo.guard';
import { SelecttramiteComponent } from './components/selecttramite/selecttramite.component';
import { NuevotramiteComponent } from './components/nuevotramite/nuevotramite.component';

const routes: Routes = [
  {
    path:'selectramite',
    component :SelecttramiteComponent,
    canActivate:[ExternoGuard]
  },
  {
    path:'nuevotramiteexterno/:idDepartamento',
    component :NuevotramiteComponent,
    canActivate:[ExternoGuard]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TramiteRoutingModule { }
