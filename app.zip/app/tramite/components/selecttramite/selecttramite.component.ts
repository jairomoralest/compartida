import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit } from '@angular/core';
import { BackendService } from 'src/app/services/backend.service';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';

@Component({
  selector: 'app-selecttramite',
  templateUrl: './selecttramite.component.html',
  styleUrls: ['./selecttramite.component.css']
})
export class SelecttramiteComponent implements OnInit {

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  list_tblb_org_departamento:any;
  public selectedIDDepartamento:any;
  public tipo_departamento='1';

  public cedula='';
  public login_usua_nomb='';
  public login_usua_apellido='';

  constructor(private backend: BackendService,private modalService:NgbModal,private routerl:Router){}

  ngOnInit() {
    this.cedula = localStorage.getItem('cedula') || '';
    this.login_usua_nomb = localStorage.getItem('nombres') || '';
    this.login_usua_apellido=localStorage.getItem('apellidos') || '';
    if(this.cedula){
      this.loadDataDepartament();
    }
  }

  loadDataDepartament() {
    this.backend.public_tblb_org_departamento(this.tipo_departamento).subscribe((response:any) => {
      if(response.status){
        this.list_tblb_org_departamento=response.list;
      }else{
        this.showModalError('No existen Departamentos para mostrar.');
      }
    },(error) => {
      this.showModalError('No existen Departamentos para mostrar.');
    }
    );
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  onChangeDepartamento(Event:any):void{
  }

  onChangeProcesoList(Event:any):void{
  }

  saveTramiteExterno(){
    if(this.selectedIDDepartamento>0){
    }else{
      this.showModalError('Debe seleccionar un departamento.');
    }
  }

  redirectNewTramite(){
    this.routerl.navigate(['/nuevotramiteexterno/', this.selectedIDDepartamento]);
  }

}
