import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgSelectConfig } from '@ng-select/ng-select';
import { ActivatedRoute, Router } from '@angular/router';
import { ElementRef } from '@angular/core';
import { BackendService } from 'src/app/services/backend.service';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';

@Component({
  selector: 'app-nuevotramite',
  templateUrl: './nuevotramite.component.html',
  styleUrls: ['./nuevotramite.component.css']
})
export class NuevotramiteComponent implements OnInit {

  btn_sendEmail:boolean=false;
  alertciudadanos:boolean=false;
  alertrequisitos:boolean=false;
  controlBtnSaveTramite:boolean = true;
  msgBusqueda:boolean = false;
  estadoTramite=false;
  intertDocument=false;
  selectedValueProceso: any;

  page: number = 1;
  count: number = 0;
  tableSize: number = 7;
  tableSizes: any = [3, 6, 9, 12];

  public objformSelTramite = {
    stra_cedula:localStorage.getItem('cedula'),
    fstra_tipo_tramite:'CERTIFICADO DE BIENES',
    fstra_estado:'REGISTRADO'
  }

  public objCiudadano = {
    ciu_ruc:'',
    ciu_nombres:'',
    ciu_apellidos:'',
    ciu_telefono:'',
    ciu_email:'',
    ciu_organizacion:'',
    ciu_cargo:'',
    ciu_abr_titulo:''
  }

  public formfillTramite = {
    fecha:"",
    asunto:"",
    numeropaginas:""
  }

  /* LISTA de datos*/
  list_tble_proc_proceso:any;
  list_tblb_org_departamento:any;
  list_tble_proc_proceso_tecnico:any;

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  nowDate: string='';
  currentDay: string='';
  currentMonth: string='';
  currentYear: string='';
  currentHour: string='';
  currentMinut: string='';
  currentSecon: string='';

  list_tblh_cr_catalogo_requisitos:any[] = [];
  receivedData: any;

  public formBuscarCombo = {
    nombre_departamento:''
  }

  public idExpediente='';
  public idTramite='';
  public fechaIngresoTramite='';
  public horaIngresoTramite='';

  public selectedIDDepartamento:any;
  public selectedIDProceso:any;
  public selectedIDTecnico:any;

  public objProceso = {
    id:'',
    id_cc:'',
    nombre_proclb:''
  }

  public idDepartamento=0;
  public objDepartamento = {
    id:0,
    nombre_departamento:''
  }

  // viene del localstorage
  public tecnicoCedula='';
  public login_usua_nomb='';
  public login_usua_apellido='';

  public objTecnicoResponsable={
    usua_cedula:'',
    usua_nomb:'',
    usua_apellido:'',
    usua_cargo:'',
    usu_departamento:''
  };

  object_requisitos = {id: '',nombre: ''};
  selectedRequisitosCombo: any[] = [];
  pdfFileObject: any;
  pdfFileObjectNUll: any;
  duplicateFiles: string[] = [];

  public obj_arbol = {
    arbol_cod_ccd_u: '',
    arbol_codi_barras: '',
    arbol_secuencial:'',
    arbol_anio:'',
    arbol_nummemorado:'',
    arbol_id_tramite:'',
    arbol_usua_cedula_login:'',
    arbol_usua_nomb_login:'',
    arbol_usua_apellido_login:'',
    arbol_exp_num_exp:''
  }

  constructor(private routerpath:Router,private router:ActivatedRoute,private config: NgSelectConfig,private modalService:NgbModal,private backend: BackendService){  }

  onTableDataChange(event: any) {
    this.page = event;
  }

  onTableSizeChange(event: any): void {
    this.tableSize = event.target.value;
    this.page = 1;
  }

  closeButtom():void{
    this.msgBusqueda=false;
  }

  ngOnInit() {
    const currentDate = new Date();
    this.currentDay = currentDate.getDate().toString();
    this.currentMonth = (currentDate.getMonth() + 1).toString();
    this.currentYear = currentDate.getFullYear().toString();
    this.currentHour= currentDate.getHours().toString();
    this.currentMinut= currentDate.getMinutes().toString();
    this.currentSecon= currentDate.getSeconds().toString();
    this.formfillTramite.fecha=this.currentDay+'/'+this.currentMonth+'/'+this.currentYear+' '+this.currentHour+':'+this.currentMinut+':'+this.currentSecon;

    const getRuta:any = this.router.snapshot.params;
    this.tecnicoCedula=String(localStorage.getItem('cedula'));
    this.login_usua_nomb=String(localStorage.getItem('nombres'));
    this.login_usua_apellido=String(localStorage.getItem('apellidos'));
    this.idDepartamento=getRuta.idDepartamento;
    this.loadData(getRuta.idDepartamento);
    this.onChangeDepartamento(getRuta.idDepartamento);
  }

  loadData(idDepartamento:any) {
    this.backend.public_tblb_org_departamento_Objecto(idDepartamento).subscribe((departamento:any) => {
      if(departamento.status===true)
        this.objDepartamento.nombre_departamento=departamento.obj.nombre_departamento;
      else
        this.showModalError('No existen Departamentos para mostrar.');
    });
    this.objCiudadano.ciu_ruc=String(localStorage.getItem('cedula'));
    this.objCiudadano.ciu_nombres=String(localStorage.getItem('nombres'));
    this.objCiudadano.ciu_apellidos=String(localStorage.getItem('apellidos'));
    this.objCiudadano.ciu_telefono=String(localStorage.getItem('telefono'));
    this.objCiudadano.ciu_email=String(localStorage.getItem('email'));
    this.objCiudadano.ciu_organizacion=String(localStorage.getItem('organizacion'));
    this.objCiudadano.ciu_cargo=String(localStorage.getItem('cargo'));
  }

  onChangeDepartamento(dep_id:number):void {
    this.backend.public_tble_proc_procesoByID(dep_id).subscribe((proceso:any) => {
      if(proceso.status){
        this.list_tble_proc_proceso=proceso.list;
      }else{
        this.list_tble_proc_proceso_tecnico=[];
        this.list_tble_proc_proceso=[];
        this.selectedRequisitosCombo=[];
        this.list_tblh_cr_catalogo_requisitos=[];
        this.showModalError('No existen Procesos para mostrar');
        this.routerpath.navigate(['/selecttramite']);
      }
    });
  }

  onChangeProcesoList(event:any):void {
    this.selectedRequisitosCombo = [];
    if(event!=undefined){
      this.objProceso.id=event.id;
      this.objProceso.id_cc=event.id_cc;
      this.objProceso.nombre_proclb=event.nombre_proceso;
      this.backend.public_tblh_cr_catalogo_requisitos_byproceso(event.id).subscribe((response:any) => {
        if(response.status){
          this.list_tblh_cr_catalogo_requisitos=response.requisitos;
        }else{
          this.list_tblh_cr_catalogo_requisitos=[];
          this.showModalError('No existen Requisitos para mostrar.');
        }
      });
      this.backend.public_tblu_migra_usuarios_tecnicos_bycod_depenid(this.idDepartamento).subscribe((response:any) => {
        if(response.status){
          this.list_tble_proc_proceso_tecnico=response.tecnicos;
        }else{
          this.list_tble_proc_proceso_tecnico=[];
          this.showModalError('No existen Técnicos para mostrar.');
        }
      });
    }else{
      this.selectedIDProceso=null;
    }
  }

  closeModal(){
    //this.modalService. .close();
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  saveTramiteExterno():void {
    this.sumFileSize=0;
    for(var i=0; i<this.myArrayFilestramite.length;i++) {
      this.sumFileSize+=parseFloat(this.myArrayFilestramite[i].size);
    }
    const valorMB=parseFloat(this.formatBytesToMB(this.sumFileSize, 2));
    if(valorMB <= 50) {
      const objJson = {
        objTecnicoResponsable:this.objTecnicoResponsable,
        objProceso:this.objProceso,
        idDepartamento:this.idDepartamento,
        objCiudadano:this.objCiudadano,
        fieldAsunto:this.formfillTramite.asunto,
        fieldNumpaginas:this.formfillTramite.numeropaginas,
        selectedRequisitosCombo:this.selectedRequisitosCombo,
        selectedReqCmblength:this.selectedRequisitosCombo.length
      }
      //console.log(objJson);
      if(this.objTecnicoResponsable.usua_cedula!==""){
        if(this.objProceso.id!==""){
          if(this.objCiudadano.ciu_ruc!==""){
            if(this.formfillTramite.asunto!==""){
              if(this.formfillTramite.numeropaginas!==""){
                if(this.selectedRequisitosCombo.length>0){
                  this.backend.create_tramite_without_files(objJson,this.myArrayFilestramite).subscribe((data:any)=>{
                      if(data.status && data.message==='Tramite Registrado'){

                        this.estadoTramite=true;
                        this.controlBtnSaveTramite=false;
                        this.btn_sendEmail=true;
                        this.idExpediente=data.idExpediente;
                        this.idTramite=data.idTramite;
                        this.fechaIngresoTramite=data.fechaIngresoTramite;
                        this.horaIngresoTramite=data.horaIngresoTramite;

                        const parsedData = JSON.parse(data.json_arbol_encoded);
                        this.obj_arbol.arbol_cod_ccd_u=parsedData.arbol_cod_ccd_u;
                        this.obj_arbol.arbol_codi_barras=parsedData.arbol_codi_barras;
                        this.obj_arbol.arbol_secuencial=parsedData.arbol_secuencial;
                        this.obj_arbol.arbol_anio=parsedData.arbol_anio;
                        this.obj_arbol.arbol_nummemorado=parsedData.arbol_nummemorado;

                        this.obj_arbol.arbol_usua_cedula_login=parsedData.arbol_usua_cedula_login;
                        this.obj_arbol.arbol_usua_nomb_login=parsedData.arbol_usua_nomb_login;
                        this.obj_arbol.arbol_usua_apellido_login=parsedData.arbol_usua_apellido_login;
                        this.obj_arbol.arbol_exp_num_exp=parsedData.arbol_exp_num_exp;
                        this.obj_arbol.arbol_id_tramite=data.idTramite;

                        this.showModal('El Trámite '+this.idTramite+' ha sido creado con éxito');
                        this.anexarTramite();
                        this.sendEmail();

                      } else {
                        this.showModalError('El Trámite No ha sido creado, Reportar de urgencia!');
                      }
                  });
                }else{
                  this.showModalError('Debe Agregar los requisitos.');
                }
              }else{
                this.showModalError('Debe Agregar el número de páginas.');
              }
            }else{
              this.showModalError('Debe Agregar un Asunto.');
            }
          }else{
            this.showModalError('Debe Seleccionar un Ciudadano.');
          }
        }else{
          this.showModalError('Debe Seleccionar al menos un proceso.');
        }
      }else{
        this.showModalError('Debe Seleccionar un Técnico Responsable.');
      }
    }else{
      this.showModalError('Los archivos tienen un peso total de : '+valorMB+' MB , y no deben exeder los 50 MB');
    }
  }

  anexarTramite():void {
    this.sumFileSize=0;
    for(var i=0; i<this.myArrayFilestramite.length;i++) {
      this.sumFileSize+=parseFloat(this.myArrayFilestramite[i].size);
    }
    const valorMB=parseFloat(this.formatBytesToMB(this.sumFileSize, 2));
    if(valorMB <= 50) {
      this.btn_sendEmail=true;
      if(this.myArrayFilestramite.length!=0){
        this.backend.create_tramite_anexo(this.obj_arbol,this.myArrayFilestramite).subscribe((data:any)=>{
          if(data.status){
            if(data.estadoDocumento=='activo'){
              //this.showModal('Los anexos se han almaceado con éxito.');
            } else {
              this.showModalError('Los anexos no se ha almaceado.');
            }
          } else{
            this.showModalError('Los anexos no se han publicado, comprobar el formato correcto de los archivos PDF!');
          }
        },
          (error: any) => {
            //console.log(error);
            if (error.status === 413) {
              this.showModalError('Ocurrió un error al intentar almacenar los anexos. Por favor, inténtelo de nuevo más tarde, Verifique el peso de los archivos PDF');
            } else {
              this.showModalError('Ocurrió un error al intentar almacenar los anexos. Por favor, inténtelo de nuevo más tarde, Verifique el peso de los archivos PDF');
            }
          }
        );
      }else{
        this.showModalError('Debe anexar los archivos.');
      }
    }else{
      this.showModalError('Los archivos tienen un peso total de : '+valorMB+' MB , y no deben exeder los 50 MB');
    }
  }

  sendEmail(): void{
    if(this.objCiudadano.ciu_email!="") {
      if(this.estadoTramite==true) {
        const objetoCiudadano = {
          tipo:'Trámite',
          idExpediente:this.idExpediente,
          usua_sumilla:this.objCiudadano.ciu_nombres+' '+this.objCiudadano.ciu_apellidos,
          idTramite:this.idTramite,
          nomTramite:this.objProceso.nombre_proclb,
          nomCiudadano:this.objCiudadano.ciu_nombres+' '+this.objCiudadano.ciu_apellidos,
          fechaIngresoTramite:this.fechaIngresoTramite,
          horaIngresoTramite:this.horaIngresoTramite,
          correo:this.objCiudadano.ciu_email
        }
        this.backend.sendEmailTramite_to_Ciudadano(objetoCiudadano).subscribe((response:any) => {
          if(response.status){
            //this.showModal('El email:'+response.email+',se ha enviado hacia el Ciudadano');
          } else {
            this.showModalError('El email:'+response.email+', no se ha enviado hacia el Ciudadano');
          }
        });
      }
    }else {
      this.showModalError('El ciudadano debe tener un email!');
    }
  }

  sendEmailButtom(): void{
    if(this.objCiudadano.ciu_email!="") {
      if(this.estadoTramite==true) {
        const objetoCiudadano = {
          tipo:'Trámite',
          idExpediente:this.idExpediente,
          usua_sumilla:this.objCiudadano.ciu_nombres+' '+this.objCiudadano.ciu_apellidos,
          idTramite:this.idTramite,
          nomTramite:this.objProceso.nombre_proclb,
          nomCiudadano:this.objCiudadano.ciu_nombres+' '+this.objCiudadano.ciu_apellidos,
          fechaIngresoTramite:this.fechaIngresoTramite,
          horaIngresoTramite:this.horaIngresoTramite,
          correo:this.objCiudadano.ciu_email
        }
        this.backend.sendEmailTramite_to_Ciudadano(objetoCiudadano).subscribe((response:any) => {
          if(response.status){
            this.showModal('El email:'+response.email+',se ha enviado hacia el Ciudadano');
          } else {
            this.showModalError('El email:'+response.email+', no se ha enviado hacia el Ciudadano');
          }
        });
      }
    }else {
      this.showModalError('El ciudadano debe tener un email!');
    }
  }


  addObjetoToListRequisitos(event: any):void{
    if(event.length==0){
      this.alertrequisitos=false;
    }else{
      this.alertrequisitos=true;
    }
  }

  addObjetoToListTecnicos(event: any):void{
    if(event!=undefined){
      this.backend.select_obj_tecnico_responsable(event.id).subscribe((response:any) =>{
        if(response.status){
            this.objTecnicoResponsable.usua_cedula=response.responsable.usua_cedula;
            this.objTecnicoResponsable.usua_nomb=response.responsable.usua_nomb;
            this.objTecnicoResponsable.usua_apellido=response.responsable.usua_apellido;
            this.objTecnicoResponsable.usua_cargo=response.responsable.usua_cargo;
            this.objTecnicoResponsable.usu_departamento=response.responsable.usu_departamento;
        } else {
          this.showModalError('No existen Datos para mostrar');
        }
      });
    }else{
      this.selectedIDTecnico=null;
    }
  }

  keyPressNumbers(event:any) {
    var charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  isNumeric(value: any): boolean {
    return !isNaN(parseFloat(value)) && isFinite(value);
  }

  selectAllForDropdownItems(items: any[]) :void{
    let allSelect = (items: any[]) => {
      items.forEach((element) => {
        element['selectedAllGroup'] = 'selectedAllGroup';
      });
    };
    allSelect(items);
  }

  data(value: any[]): void {
    throw new Error('Function not implemented.');
  }

  parseString(cedula: number): string {
    throw new Error('Function not implemented.');
  }

  clearTramite(): void{
    this.sumFileSize=0;
    const currentDate = new Date();
    this.currentDay = currentDate.getDate().toString();
    this.currentMonth = (currentDate.getMonth() + 1).toString();
    this.currentYear = currentDate.getFullYear().toString();
    this.currentHour= currentDate.getHours().toString();
    this.currentMinut= currentDate.getMinutes().toString();
    this.currentSecon= currentDate.getSeconds().toString();
    this.formfillTramite.fecha=this.currentDay+'/'+this.currentMonth+'/'+this.currentYear+' '+this.currentHour+':'+this.currentMinut+':'+this.currentSecon;

    this.idExpediente='';
    this.idTramite='';
    this.formfillTramite.asunto="";
    this.formfillTramite.numeropaginas="";

    this.alertciudadanos=false;
    this.selectedIDProceso=null;
    this.selectedIDTecnico=null;
    this.selectedRequisitosCombo=[];
    this.list_tble_proc_proceso_tecnico=[];
    this.list_tblh_cr_catalogo_requisitos=[];
    this.myArrayFilestramite=[];
    this.controlBtnSaveTramite=true;
    this.btn_sendEmail=false;
  }

  /* LOAD PDF */
  filestramite:any;
  @ViewChild('fileInputRefTramite') fileInputRefTramite!: ElementRef<HTMLInputElement>;
  public myArrayFilestramite:any = [];

  sumFileSize: number = 0;

  onDragOverTramite(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
  }

  onDropTramite(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    const files = event.dataTransfer?.files;
    if (files) {
      this.handleFilesTramite(files);
    }
  }

  handleFilesTramite(files: FileList | null) {
    if (files) {
      this.duplicateFiles = [];
      for (let i = 0; i < files.length; i++) {
        var file = files[i];
        var fileNameExists = this.myArrayFilestramite.some((f: any) => f.name === file.name);
        if (fileNameExists) {
          this.duplicateFiles.push(file.name);
        } else if (file.type === 'application/pdf' && file.size <= 52428800) {
          this.myArrayFilestramite.push(file);
        } else {
          this.showModalError('Debe cargar un documento en formato PDF, con un peso inferior a 50 MB');
        }
      }
      if (this.duplicateFiles.length === 1) {
        this.showModalError(`El archivo ${this.duplicateFiles.join(', ')}, ya se ha ingresado.`);
      }else if (this.duplicateFiles.length > 1) {
        this.showModalError(`Existen archivos que ya se han ingresado: ${this.duplicateFiles.join(', ')}`);
      }
    }
  }

  onFilesSelectedTramite(event: Event): void {
    this.filestramite = (event.target as HTMLInputElement).files;
    if (this.filestramite) {
      this.duplicateFiles = [];
      for (let i = 0; i < this.filestramite.length; i++) {
        var file = this.filestramite[i];
        var fileNameExists = this.myArrayFilestramite.some((f: any) => f.name === file.name);
        if (fileNameExists) {
          this.duplicateFiles.push(file.name);
        } else if (file.type === 'application/pdf' && file.size <= 52428800) {
          this.myArrayFilestramite.push(file);
        } else {
          this.showModalError('Debe cargar un documento en formato PDF, con un peso inferior a 50 MB');
        }
      }
      if (this.duplicateFiles.length === 1) {
        this.showModalError(`El archivo ${this.duplicateFiles.join(', ')}, ya se ha ingresado.`);
      }else if (this.duplicateFiles.length > 1) {
        this.showModalError(`Existen archivos que ya se han ingresado: ${this.duplicateFiles.join(', ')}`);
      }
    }
  }

  deleteFileTramite(index: number): void {
    this.myArrayFilestramite.splice(index, 1);
  }

  formatBytesToMB(bytes:number, decimals = 2) {
    if (bytes === 0)
      return '0 MB';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const mb = bytes / Math.pow(k, 2);
    return `${parseFloat(mb.toFixed(dm))} MB`;
  }

  downloadFormularioPDF():void{
    this.backend.downloadFormularioPDF(this.pdfFileObjectNUll);
  }

}
