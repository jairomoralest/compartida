import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BackendService } from 'src/app/services/backend.service';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';

@Component({
  selector: 'app-documento',
  templateUrl: './documento.component.html',
  styleUrls: ['./documento.component.css']
})
export class DocumentoComponent implements OnInit {

  nombreFuente='';
  idExpediente='';

  public showtramiteEstado:boolean=false;
  public tramiteEstado:boolean=false;

  cedulaLogueado:string='';
  btn_ticket:boolean = true;
  btn_desmaterializa:boolean = true;
  btn_enviaremail:boolean = true;

  // datos tramite
  public idTramite='';
  public fechaIngresoTramite='';
  public horaIngresoTramite='';

  login_usua_nomb='';
  login_usua_apellido='';


  estadoDocumento=false;

  page: number = 1;
  count: number = 0;
  tableSize: number = 7;
  tableSizes: any = [3, 6, 9, 12];

  shownavbar=true;
  list_tble_tecnico:any;
  list_tble_recep_doc_fisico:any;
  list_tble_bg_exp_cuadro_clasificacion:any;
  list_tble_recep_doc_tipo:any;

  public selectedIDFisico:any;
  public selectedIDCCLA:any;
  public selectedIDTipo:any;
  public selectedIDTecnico:any;

  public formfillDocumento = {
    fecha:"",
    asunto:"",
    descripcion:"",
    numeropaginas:""
  }

  nowDate: string='';
  currentDay: string='';
  currentMonth: string='';
  currentYear: string='';
  currentHour: string='';
  currentMinut: string='';
  currentSecon: string='';

  public formSelCiudadano = {
    ciu_ruc:'',
    ciu_nombres:'',
    ciu_apellidos:'',
    ciu_telefono:'',
    ciu_organizacion:'',
    ciu_cargo:'',
    ciu_email:''
  }

  /*Objeto del tecnico -> tabla migra*/
  public objTecnico = {
    usua_cargo:'',
    usua_cedula:'',
    usu_departamento:'',
    usua_nomb:'',
    usua_apellido:'',
    usua_nombrecompleto:'',
    usua_email:''
  }

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  selectFisico='FIS';
  selectTipo='TIP';

  public obj_arbol = {
    arbol_cod_ccd_u: '',
    arbol_codi_barras: '',
    arbol_secuencial:'',
    arbol_anio:'',
    arbol_nummemorado:'',
    arbol_id_tramite:'',
    arbol_usua_cedula_login:'',
    arbol_usua_nomb_login:'',
    arbol_usua_apellido_login:'',
    arbol_exp_num_exp:''
  }

  dataControlMigra:boolean = false;

  @ViewChild('fileInputRefTramite') fileInputRefTramite!: ElementRef<HTMLInputElement>;

  sumFileSize: number = 0;

  filestramite:any;
  public myArrayFilestramite:any = [];
  myArrayFilestramiteSize:number =0;

  duplicateFiles: string[] = [];

  constructor(private modalService:NgbModal,private backend: BackendService){  }

  ngOnInit() {
    const currentDate = new Date();
    this.currentDay = currentDate.getDate().toString();
    this.currentMonth = (currentDate.getMonth() + 1).toString();
    this.currentYear = currentDate.getFullYear().toString();
    this.currentHour= currentDate.getHours().toString();
    this.currentMinut= currentDate.getMinutes().toString();
    this.currentSecon= currentDate.getSeconds().toString();
    this.formfillDocumento.fecha=this.currentDay+'/'+this.currentMonth+'/'+this.currentYear+' '+this.currentHour+':'+this.currentMinut+':'+this.currentSecon;
    this.cedulaLogueado=String(localStorage.getItem('cedula'));
    this.login_usua_nomb=String(localStorage.getItem('nombres'));
    this.login_usua_apellido=String(localStorage.getItem('apellidos'));

    this.formSelCiudadano.ciu_ruc=String(localStorage.getItem('cedula'));
    this.formSelCiudadano.ciu_ruc=String(localStorage.getItem('cedula'));
    this.formSelCiudadano.ciu_nombres=String(localStorage.getItem('nombres'));
    this.formSelCiudadano.ciu_apellidos=String(localStorage.getItem('apellidos'));
    this.formSelCiudadano.ciu_telefono=String(localStorage.getItem('telefono'));
    this.formSelCiudadano.ciu_email=String(localStorage.getItem('email'));
    this.formSelCiudadano.ciu_organizacion=String(localStorage.getItem('organizacion'));
    this.formSelCiudadano.ciu_cargo=String(localStorage.getItem('cargo'));
    this.loadData();
  }

  loadData():void {

    this.backend.getList_tble_bg_exp_cuadro_clasificacion1().subscribe((listacclas: any) => {
      if (listacclas.status === true) {
        this.list_tble_bg_exp_cuadro_clasificacion = listacclas.list;
        if (this.list_tble_bg_exp_cuadro_clasificacion.length > 0) {
          this.selectedIDCCLA = this.list_tble_bg_exp_cuadro_clasificacion[0].condispo;
        } else {
          this.selectedIDCCLA = null;
        }
      } else {
        this.showModalError('No existen el Cuadro de clasificación para mostrar.');
      }
    });

    this.backend.getList_tble_recep_doc_fisico(this.selectFisico).subscribe((fisico: any) => {
      if (fisico.status === true) {
        this.list_tble_recep_doc_fisico = fisico.list;
        if (this.list_tble_recep_doc_fisico.length > 0) {
          this.selectedIDFisico = this.list_tble_recep_doc_fisico[0].id;
        } else {
          this.selectedIDFisico = null;
        }
      } else {
        this.showModalError('No existen Físicos para mostrar.');
      }
    });

    this.backend.getList_tble_recep_doc_tipo(this.selectTipo).subscribe((tipo:any) => {
      if(tipo.status===true)
        this.list_tble_recep_doc_tipo=tipo.list;
      else
        this.showModalError('No existen Tipos para mostrar.');
    });

    this.backend.getList_tble_recep_doc_tecnico_migra().subscribe((response:any) => {
      if(response.status){
        this.list_tble_tecnico=response.list;
        if (this.list_tble_tecnico.length > 0) {
          this.selectedIDTecnico = this.list_tble_tecnico[0].id;          ;
        } else {
          this.selectedIDTecnico = null;
        }
      }else{
        this.list_tble_tecnico=[];
        this.showModalError('No existen Técnicos para mostrar.');
      }
    });
  }

  onChangeCClasificacion(event:any):void {
    if(event!==undefined){
      //console.log(this.selectedIDFisico);
      //console.log(event);
    }
  }

  onChangeFisicoList(event:any):void {
    if(event!==undefined){
      this.nombreFuente=event.nombre;
      //console.log(event.nombre);
      //console.log(event);
    }
  }

  onChangeTipoList(event:any):void {
    if(event!==undefined){
      //console.log(this.selectedIDTipo);
      //console.log(event);
    }
  }

  onChangeTecnicoList(event:any):void {
    //console.log(this.selectedIDTecnico);
    //console.log(event);
  }

  redirectNewTramite():void {
  }

  onDragOverTramite(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
  }

  onDropTramite(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    const files = event.dataTransfer?.files;
    if (files) {
      this.handleFilesTramite(files);
    }
  }

  handleFilesTramite(files: FileList | null) {
    if (files) {
      this.duplicateFiles = []; // Reset duplicateFiles array
      for (let i = 0; i < files.length; i++) {
        var file = files[i];
        var fileNameExists = this.myArrayFilestramite.some((f: any) => f.name === file.name);
        if (fileNameExists) {
          this.duplicateFiles.push(file.name);
        } else if (file.type === 'application/pdf' && file.size <= 52428800) {
          this.myArrayFilestramite.push(file);
        } else {
          this.showModalError('Debe cargar un documento en formato PDF, con un peso inferior a 50 MB');
        }
      }
      if (this.duplicateFiles.length === 1) {
        this.showModalError(`El archivo ${this.duplicateFiles.join(', ')}, ya se ha ingresado.`);
      }else if (this.duplicateFiles.length > 1) {
        this.showModalError(`Existen archivos que ya se han ingresado: ${this.duplicateFiles.join(', ')}`);
      }
    }
  }

  onFilesSelectedTramite(event: Event): void {
    this.filestramite = (event.target as HTMLInputElement).files;
    if (this.filestramite) {
      this.duplicateFiles = [];
      for (let i = 0; i < this.filestramite.length; i++) {
        var file = this.filestramite[i];
        var fileNameExists = this.myArrayFilestramite.some((f: any) => f.name === file.name);
        if (fileNameExists) {
          this.duplicateFiles.push(file.name);
        } else if (file.type === 'application/pdf' && file.size <= 52428800) {
          this.myArrayFilestramite.push(file);
        } else {
          this.showModalError('Debe cargar un documento en formato PDF, con un peso inferior a 50 MB');
        }
      }
      if (this.duplicateFiles.length === 1) {
        this.showModalError(`El archivo ${this.duplicateFiles.join(', ')}, ya se ha ingresado.`);
      }else if (this.duplicateFiles.length > 1) {
        this.showModalError(`Existen archivos que ya se han ingresado: ${this.duplicateFiles.join(', ')}`);
      }
    }
  }

  deleteFileDocumento(index: number): void {
    this.myArrayFilestramite.splice(index, 1);
  }

  formatBytesToMB(bytes:number, decimals = 2) {
    if (bytes === 0)
      return '0 MB';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const mb = bytes / Math.pow(k, 2);
    return `${parseFloat(mb.toFixed(dm))} MB`;
  }

  onTableDataChange(event: any) {
    this.page = event;
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  saveDocumento():void {
    this.sumFileSize=0;
    for(var i=0; i<this.myArrayFilestramite.length;i++) {
      this.sumFileSize+=parseFloat(this.myArrayFilestramite[i].size);
    }
    const valorMB=parseFloat(this.formatBytesToMB(this.sumFileSize, 2));
    if(valorMB <= 50) {
      const objJson = {
        idcuadroClasificacion:this.selectedIDCCLA,
        objTecnico:this.objTecnico,
        selectedIDTipo:this.selectedIDTipo,            // agregar tipo
        selectedIDFisico:this.selectedIDFisico,        // agregar fisico
        formfillDocumento:this.formfillDocumento,      // agregar varios
        formSelCiudadano:this.formSelCiudadano,        // agregar agregar ciudadano
        selectedIDTecnico:this.selectedIDTecnico,      // agregar tecnico
        nombreFuente:this.nombreFuente
      }
      //console.log(objJson);
      if(this.myArrayFilestramite.length!=0){
        if(this.selectedIDCCLA!=undefined){
          if(this.selectedIDFisico!=undefined){
            if(this.selectedIDTipo!=undefined){
              if(this.formfillDocumento.fecha!=""){
                if(this.formfillDocumento.asunto!=""){
                  if(this.formfillDocumento.descripcion!=""){

                    if(this.formSelCiudadano.ciu_ruc!="" || this.formSelCiudadano.ciu_nombres!="" || this.formSelCiudadano.ciu_apellidos!="" || this.formSelCiudadano.ciu_telefono!="" || this.formSelCiudadano.ciu_email!="" || this.formSelCiudadano.ciu_organizacion!="" || this.formSelCiudadano.ciu_cargo!=""){
                      if(this.formfillDocumento.numeropaginas!=""){
                          this.backend.create_documento_without_files(objJson).subscribe((data:any)=>{
                            if(data.status){
                              this.estadoDocumento=true;
                              this.idExpediente=data.idExpediente;

                              const parsedData = JSON.parse(data.json_arbol_encoded);
                              this.obj_arbol.arbol_cod_ccd_u=parsedData.arbol_cod_ccd_u;
                              this.obj_arbol.arbol_codi_barras=parsedData.arbol_codi_barras;
                              this.obj_arbol.arbol_secuencial=parsedData.arbol_secuencial;
                              this.obj_arbol.arbol_anio=parsedData.arbol_anio;
                              this.obj_arbol.arbol_nummemorado=parsedData.arbol_nummemorado;

                              this.obj_arbol.arbol_usua_cedula_login=parsedData.arbol_usua_cedula_login;
                              this.obj_arbol.arbol_usua_nomb_login=parsedData.arbol_usua_nomb_login;
                              this.obj_arbol.arbol_usua_apellido_login=parsedData.arbol_usua_apellido_login;
                              this.obj_arbol.arbol_exp_num_exp=parsedData.arbol_exp_num_exp;
                              this.idTramite=data.idTramite;
                              this.obj_arbol.arbol_id_tramite=data.idTramite;

                              this.fechaIngresoTramite=data.fechaIngresoTramite;
                              this.horaIngresoTramite=data.horaIngresoTramite;

                              this.showtramiteEstado=true;
                              this.tramiteEstado=true;

                              this.showModal('El Documento '+this.idTramite+' ha sido creado con éxito.');
                              this.anexarDocumento();
                              this.sendEmailCiudadano();

                            } else{
                              this.showModalError('El documento no se ha creado, vuela a generar un nuevo documento');
                            }
                          });
                      }else{
                        this.showModalError('Debe agregar el número de páginas');
                      }
                    }else{
                      this.showModalError('Debe agregar ciudadano');
                    }
                  }else{
                    this.showModalError('Debe agregar una descripción');
                  }
                }else{
                  this.showModalError('Debe agregar un asunto');
                }
              }else{
                this.showModalError('Debe agregar una fecha');
              }
            }else{
            this.showModalError('Debe seleccionar un tipo');
            }
          }else{
            this.showModalError('Debe Seleccionar un origen de fuente');
          }
        }else{
          this.showModalError('Debe Seleccionar el Cuadro de calificación');
        }
      }else{
        this.showModalError('Debe anexar los archivos en formato PDF.');
      }
    }else{
      this.showModalError('Los archivos tienen un peso total de : '+valorMB+' MB , y no deben exeder los 50 MB');
    }
  }

  anexarDocumento():void {
    this.sumFileSize=0;
    for(var i=0; i<this.myArrayFilestramite.length;i++) {
      this.sumFileSize+=parseFloat(this.myArrayFilestramite[i].size);
    }
    const valorMB=parseFloat(this.formatBytesToMB(this.sumFileSize, 2));
    if(valorMB <= 50) {
      if(this.myArrayFilestramite.length!=0){
        this.backend.create_documento_anexo(this.obj_arbol,this.myArrayFilestramite).subscribe((data:any)=>{
          if(data.status){
            if(data.estadoDocumento=='activo'){
              //this.showModal('El Documento '+this.obj_arbol.arbol_id_tramite+' ha sido creado con éxito , y se ha enviado hacia el email');
              this.sendEmailCiudadano();
            } else {
              this.showModalError('Los anexos no se ha almaceado.');
            }
          }else{
            this.showModalError('Los anexos no se han publicado, comprobar el formato correcto de los archivos PDF!');
          }
        },
          (error: any) => {
            this.showModalError('Ocurrió un error al intentar almacenar los anexos. Por favor, inténtelo de nuevo más tarde, Verifique el peso de los archivos PDF');
          }
        );
      }else{
        this.showModalError('Debe anexar los archivos.');
      }
    }else{
      this.showModalError('Los archivos tienen un peso total de : '+valorMB+' MB , y no deben exeder los 50 MB');
    }
  }

  sendEmailCiudadano(){
    if(this.formSelCiudadano.ciu_email!="") {
      if(this.estadoDocumento==true) {
        const objetoCiudadano = {
          idExpediente:this.idExpediente,
          usua_sumilla:this.formSelCiudadano.ciu_nombres+' '+this.formSelCiudadano.ciu_apellidos,
          tipo:'Documento',
          idTramite:this.idTramite,
          nomTramite:this.formfillDocumento.asunto,
          nomCiudadano:this.formSelCiudadano.ciu_nombres+' '+this.formSelCiudadano.ciu_apellidos,
          fechaIngresoTramite:this.fechaIngresoTramite,
          horaIngresoTramite:this.horaIngresoTramite,
          correo:this.formSelCiudadano.ciu_email
        }
        this.backend.sendEmailTramite_to_Ciudadano(objetoCiudadano).subscribe((response:any) => {
          if(response.status){
            //this.showModal('El email:'+response.email+',se ha enviado hacia el Ciudadano');
          } else {
            this.showModalError('El email:'+response.email+', no se ha enviado hacia el Ciudadano');
          }
        });
      }
    }else {
      this.showModalError('El ciudadano debe tener un email!');
    }
  }

  sendEmailCiudadanoButton(){
    if(this.formSelCiudadano.ciu_email!="") {
      if(this.estadoDocumento==true) {
        const objetoCiudadano = {
          idExpediente:this.idExpediente,
          tipo:'Documento',
          idTramite:this.idTramite,
          nomTramite:this.formfillDocumento.asunto,
          nomCiudadano:this.formSelCiudadano.ciu_nombres+' '+this.formSelCiudadano.ciu_apellidos,
          fechaIngresoTramite:this.fechaIngresoTramite,
          horaIngresoTramite:this.horaIngresoTramite,
          correo:this.formSelCiudadano.ciu_email
        }
        this.backend.sendEmailTramite_to_Ciudadano(objetoCiudadano).subscribe((response:any) => {
          if(response.status){
            this.showModal('El email:'+response.email+',se ha enviado hacia el Ciudadano');
          } else {
            this.showModalError('El email:'+response.email+', no se ha enviado hacia el Ciudadano');
          }
        });
      }
    }else {
      this.showModalError('El ciudadano debe tener un email!');
    }
  }

  newDocumento():void {
    const currentDate = new Date();
    this.currentDay = currentDate.getDate().toString();
    this.currentMonth = (currentDate.getMonth() + 1).toString();
    this.currentYear = currentDate.getFullYear().toString();
    this.currentHour= currentDate.getHours().toString();
    this.currentMinut= currentDate.getMinutes().toString();
    this.currentSecon= currentDate.getSeconds().toString();
    this.formfillDocumento.fecha=this.currentDay+'/'+this.currentMonth+'/'+this.currentYear+' '+this.currentHour+':'+this.currentMinut+':'+this.currentSecon;

    this.sumFileSize=0;
    this.nombreFuente='';
    this.idExpediente='';
    this.estadoDocumento=false;

    this.formfillDocumento.asunto="";
    this.formfillDocumento.descripcion="";
    this.formfillDocumento.numeropaginas="";

    this.selectedIDFisico='';
    this.selectedIDTipo='';
    this.selectedIDCCLA='';

    this.selectedIDTecnico=null;
    this.myArrayFilestramite=[];
    this.tramiteEstado=false;
    this.showtramiteEstado=false;
  }

  formatDecimal(value: number, fractionDigits: number): string {
    return value.toFixed(fractionDigits);
  }

  keyPressNumbers(event:any) {
    var charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  keyPressCharacters(event: any) {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (!(charCode >= 65 && charCode <= 90) &&    // uppercase letters
        !(charCode >= 97 && charCode <= 122) &&   // lowercase letters
        charCode !== 32 &&    // space
        charCode !== 8 &&     // backspace
        charCode !== 9 &&     // tab
        charCode !== 46       // delete
    ) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  isNumeric(value: any): boolean {
    return !isNaN(parseFloat(value)) && isFinite(value);
  }

  isText(value: any): boolean {
    return typeof value === 'string';
  }

  addObjetoToListTecnicos(event:any):void{
    if(event!=undefined){
      this.backend.getList_tble_recep_doc_tecnico_migraByID(event.id).subscribe((response:any) => {
        if(response.status){
          this.objTecnico=response.list;
        }else{
        }
      });
    }else{
      this.selectedIDTecnico=null;
    }
  }

}
