import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocumentoComponent } from './components/documento/documento.component';
import { ExternoGuard } from '../guard/externo.guard';

const routes: Routes = [

  {
    path:'documento',
    component :DocumentoComponent,
    canActivate:[ExternoGuard]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecepcionRoutingModule { }
