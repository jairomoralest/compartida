import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecepcionRoutingModule } from './recepcion-routing.module';
import { DocumentoComponent } from './components/documento/documento.component';
import { FormsModule } from '@angular/forms';           // ngForm OK
import { NgxPaginationModule } from 'ngx-pagination';   // pagination
import { NgSelectModule } from '@ng-select/ng-select';  // select OK

@NgModule({
  declarations: [
    DocumentoComponent
  ],
  imports: [
    CommonModule,
    RecepcionRoutingModule,
    FormsModule,
    NgxPaginationModule,
    NgSelectModule
  ]
})
export class RecepcionModule { }
