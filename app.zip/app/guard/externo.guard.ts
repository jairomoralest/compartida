import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Route, Router, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ExternoGuard implements CanActivate{

  constructor(private ruta: Router){ }

  async canActivate(route:ActivatedRouteSnapshot,state: RouterStateSnapshot): Promise<boolean>{

    const rol_id:any = localStorage.getItem('user');
    if(rol_id==2){
      return true;
    }else{
      this.ruta.navigate(['login']);
      return false;
    }
  }

}
