import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BackendService } from 'src/app/services/backend.service';
import { EventEmitter, Input } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { NgxUiLoaderService } from 'ngx-ui-loader';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {

  public formUser = {
    id:null,
    cedula:null,
    email:null,
    nombres:null,
    apellidos:null,
    role_id:null,
    role_nombre:'',
    estado:null,
    tipo_usuario:null
  }

  list_tble_recep_doc_fisico:any;
  public selectedIDFisico:any;
  public userState:any;

  @Input() public modalinfoUpdate:any;
  valueEmitter: EventEmitter<string> = new EventEmitter<string>();

  public modalinfo = {
    head: 'Mensaje informativo',
    body: 'Usted ha salido del sistema.'
  }

  public error:any=[];
  editPersona : any = {};
  datosPersona : any = {};
  public dtPerson = new Array<any>();
  public stateuserType: string[] = ['CIUDADANO','CONTRATISTA'];
  public stateList: string[] = ['ACTIVO','INACTIVO','REGISTRADO','ESPERA'];

  constructor(private backend:BackendService,  private router:ActivatedRoute,private routerpath:Router,private modalService:NgbModal,protected activeModal: NgbActiveModal,private sharedService: SharedService,private ngxService: NgxUiLoaderService) { }

  async ngOnInit() {
    this.userState=this.modalinfoUpdate.estado;
    this.formUser.id=this.modalinfoUpdate.id;
    this.formUser.cedula=this.modalinfoUpdate.cedula;
    this.formUser.nombres=this.modalinfoUpdate.nombres;
    this.formUser.apellidos=this.modalinfoUpdate.apellidos;
    this.formUser.email=this.modalinfoUpdate.email;
    this.formUser.estado=this.modalinfoUpdate.estado;
    this.formUser.tipo_usuario=this.modalinfoUpdate.tipo_usuario;
    if(this.modalinfoUpdate.role_id==1){
      this.formUser.role_nombre='ADMINISTRADOR';
    }else{
      this.formUser.role_nombre='EXTERNO';
    }
  }

  btnClickBack(){
    this.routerpath.navigate(['/listuser']);
  }

  handleError(error:any){
    this.error= error.error.errors;
  }

  submitUpdateCiudadano():void{
    this.ngxService.start();
    this.backend.updateUserState(this.formUser).subscribe((data:any) => {
      if(data.status===true){
        this.ngxService.stop();
        this.closeModal();
        if(data.estadoCorreo){
          this.showModal('El usuario ha sido actualizado con éxito y se le ha notificado a través de su correo electrónico.');
        }else{
          this.showModal('El usuario ha sido actualizado con éxito');
        }
        this.sendDataToComponentB(1);
      }
    },
    (error) => {
      this.ngxService.stop();
      this.showModalError('Error del sistema, por favor reportar administrador.');
    });
  }

  sendDataToComponentB(numero:any) {
    this.sharedService.sendFirstDataCIU(numero);
  }

  closeModal():void{
    this.activeModal.close();
  }

  onChangeFisicoList(event:any):void {
    if(event!==undefined){
      //this.nombreFuente=event.nombre;
      //console.log(event.nombre);
    }
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  onChangeEstado(event: any) {
    // Handle state change
  }

}
