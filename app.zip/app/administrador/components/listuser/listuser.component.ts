import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BackendService } from 'src/app/services/backend.service';
import { Location } from '@angular/common';
import { EdituserComponent } from '../edituser/edituser.component';
import { ShareAService } from 'src/app/services/sharea.service';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/services/shared.service';
import { DialogAdviceComponent } from 'src/app/utilities/components/dialog-advice/dialog-advice.component';

@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent {

  POSTS: any;
  page: number = 1;
  count: number = 0;
  tableSize: number = 10;
  tableSizes: any = [3, 6, 9, 12];
  dtPerson = new Array<any>();

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  public modalinfoUpdate = {
    head: 'Mensaje informativo',
    body: '',
    id:'',
    cedula:'',
    nombres:'',
    apellidos:'',
    email:'',
    role_id:'',
    estado:'',
    tipo_usuario:''
  }

  constructor(private backend:BackendService,location: Location,private router:Router,private modalService:NgbModal,private sharedService: SharedService,private ngxService: NgxUiLoaderService){}

  ngOnInit(): void {
    this.ngxService.start();
    this.sharedService.ciuData$.subscribe((data:any) => {
      if(data==1){
        this.listUsers();
      }
    });

    this.fetchPosts();
    this.backend.listciudadano().subscribe((response:any) =>{
      if(response.status){
        this.dtPerson= response.listuser
      }else{

      }
    });
    this.ngxService.stop();
  }

  onChangeFisicoList(event:any):void {
    if(event!==undefined){
      //this.nombreFuente=event.nombre;
      //console.log(event.nombre);
    }
  }

  listUsers(){
    this.fetchPosts();
    this.backend.listciudadano().subscribe( (response:any) =>{
      if(response.status){
        this.dtPerson= response.listuser
      }else{
        this.showModalError("Error al cargar los tramites, consultar al administrador del sitio.");
      }
    });
  }

  deletePerson(id:number){
  }

  fetchPosts(): void {
    this.backend.listciudadano().subscribe((response:any) => {
      if(response.status){
        this.POSTS= response.listuser
      }else{

      }
      },
        (error) => {
          console.log(error);
        }
    );
  }

  onTableDataChange(event: any) {
    this.page = event;
    this.fetchPosts();
  }

  onTableSizeChange(event: any): void {
    this.tableSize = event.target.value;
    this.page = 1;
    this.fetchPosts();
  }

  sendData(post:any) {
    const encodedJsonData = encodeURIComponent(JSON.stringify(post));
    this.router.navigate(['/personactive', encodedJsonData]);
  }

  updateUsuario(post:any):void{
    console.log(post);

    if(post.apellidos!=="" && post.nombres!==""){
      this.ngxService.start();
      this.backend.getUserById(post.id).subscribe((data:any)=>{
        if(data.state==true){
          this.ngxService.stop();
          this.modalinfoUpdate.id=data.objUser.id;
          this.modalinfoUpdate.cedula=data.objUser.cedula;
          this.modalinfoUpdate.email=data.objUser.email;
          this.modalinfoUpdate.role_id=data.objUser.role_id;
          this.modalinfoUpdate.estado=data.objUser.estado;
          this.modalinfoUpdate.nombres=data.objUser.nombres;
          this.modalinfoUpdate.apellidos=data.objUser.apellidos;
          this.modalinfoUpdate.tipo_usuario=data.objUser.tipo_usuario;
          const modalRef = this.modalService.open(EdituserComponent, { size: 'lg', backdrop: 'static' });
          modalRef.componentInstance.modalinfoUpdate = this.modalinfoUpdate;
        }
      });
    }else{
      this.showModalAdvice("El usuario registrado debe completar todos los datos.");
    }
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalAdvice(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogAdviceComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

}
