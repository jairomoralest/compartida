import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BackendService } from 'src/app/services/backend.service';

@Component({
  selector: 'app-detailuser',
  templateUrl: './detailuser.component.html',
  styleUrls: ['./detailuser.component.css']
})
export class DetailuserComponent {

  cad:string = '';
  arrayPdf= new Array();

  constructor(private router:ActivatedRoute,private backend:BackendService,private ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.ngxService.start();
    const ruta:any = this.router.snapshot.params;
    this.backend.getUserFilesListPDFById(ruta.id).subscribe((data:any)=>{
      if(data.status){
        this.arrayPdf=data.listFiles
      }else{

      }
    });
    this.ngxService.stop();
  }

  formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0)
      return '0 MB';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const mb = bytes / Math.pow(k, 2);
    return `${parseFloat(mb.toFixed(dm))} MB`;
  }

  downloadPDFFile(pdfFileObject:any):void{
    this.ngxService.start();
    this.backend.downloadPDFBypathfileAdmin(pdfFileObject);
    this.ngxService.stop();
  }

  showPDFFile(pdfFileObject:any):void{
    this.ngxService.start();
    this.backend.showPDFBypathfileAdmin(pdfFileObject);
    this.ngxService.stop();
  }

}
