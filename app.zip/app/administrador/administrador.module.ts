import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { AdministradorRoutingModule } from './administrador-routing.module';
import { DetailuserComponent } from './components/detailuser/detailuser.component';
import { EdituserComponent } from './components/edituser/edituser.component';
import { ListuserComponent } from './components/listuser/listuser.component';
import { NgSelectModule } from '@ng-select/ng-select';  // select OK

@NgModule({
  declarations: [
    DetailuserComponent,
    EdituserComponent,
    ListuserComponent
  ],
  imports: [
    CommonModule,
    AdministradorRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule,
    NgSelectModule
  ]
})
export class AdministradorModule { }
