import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailuserComponent } from './components/detailuser/detailuser.component';
import { AuthenticateGuard } from '../guard/authenticate.guard';
import { ListuserComponent } from './components/listuser/listuser.component';
import { EdituserComponent } from './components/edituser/edituser.component';


const routes: Routes = [
  {
    path:'detailuser/:id',
    component :DetailuserComponent,
    canActivate:[AuthenticateGuard]
  },
  {
    path:'listuser',
    component :ListuserComponent,
    canActivate:[AuthenticateGuard]
  },
  {
    path:'personactive/:id',
    component :EdituserComponent,
    canActivate:[AuthenticateGuard]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministradorRoutingModule { }
