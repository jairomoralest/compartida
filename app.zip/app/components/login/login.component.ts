import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subscription } from 'rxjs';
import { BackendService } from 'src/app/services/backend.service';
import { LoginService } from 'src/app/services/login.service';
import { NavbarService } from 'src/app/services/navbar.service';
import { StorageService } from 'src/app/services/storage.service';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy{

  message:any;
  editMessage:any;
  showPassword = false;
  showlogin:boolean=true;
  subscription:Subscription;

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  form:any  = {
    email:null,
    password:null
  }

  public error:any=[];
  constructor(private loginService:LoginService,private navbarService:NavbarService,private backend:BackendService,private router:Router,private modalService:NgbModal,private storageService: StorageService,private ngxService: NgxUiLoaderService) {
    this.subscription=this.loginService.shownabvar.subscribe((value)=>{
      this.showlogin=value;
    });
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  ngOnInit(): void {
    if(localStorage.getItem('user')!==null){
      this.navbarService.hide();
      this.loginService.display();
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  submitLogin(){
    this.ngxService.start();
    this.backend.emaillogin(this.form).subscribe((resp:any) => {
      if(resp.status){
        this.backend.login(this.form).subscribe((resp:any) => {
          if(resp.objUser.estado==="REGISTRADO"){
            this.ngxService.stop();
            this.showModalError('Debe completar el registro de datos para poder acceder a su cuenta.');
          }else if(resp.objUser.estado==="ESPERA"){
            this.ngxService.stop();
            this.showModalError('El administrador debe habilitar su cuenta después de validar sus datos.');
          }else if(resp.objUser.estado==="INACTIVO"){
            this.ngxService.stop();
            this.showModalError('Su cuenta está desactivada, comuníquese con el administrador del sitio.');
          }else if(resp.objUser.estado==="ACTIVO"){
            this.ngxService.stop();
            if(resp.passwordstate){
              this.ngxService.stop();
              localStorage.setItem('token', resp.token);
              localStorage.setItem('cedula',resp.objUser.cedula);
              localStorage.setItem('user',resp.objUser.role_id);
              localStorage.setItem('email',resp.objUser.email);
              localStorage.setItem('telefono',resp.objUser.telefono);
              localStorage.setItem('nombres',resp.objUser.nombres);
              localStorage.setItem('apellidos',resp.objUser.apellidos);
              localStorage.setItem('organizacion',resp.objUser.organizacion);
              localStorage.setItem('cargo',resp.objUser.cargo);
              localStorage.setItem('tipo_usuario',resp.objUser.tipo_usuario);
              this.loginService.hide();
              this.navbarService.display();
            }else{
              this.ngxService.stop();
              this.showModalError('La contraseña es incorrecta. Puede acceder a la opción de recuperación de contraseña');
            }
          }
        },
          (error) => {
            this.ngxService.stop();
            this.showModalError('Error del sistema, por favor reportar administrador.');
        });
    }else{
      this.ngxService.stop();
      this.showModalError('El correo electrónico no existe.');
    }
    },
      (error) => {
        this.ngxService.stop();
      this.showModalError('Error del sistema, por favor reportar administrador.');
    });
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

}
