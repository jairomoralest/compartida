import { Component, Input, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { LoginService } from 'src/app/services/login.service';
import { NavbarService } from 'src/app/services/navbar.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnDestroy{

  email:any;
  rol_id:any;
  shownavbar:boolean=true;
  subscription:Subscription;

  public isCollapse_est_list_tram = true;
  public isCollapse_est_cta = true;
  public isCollapse_est_tit_cred = true;
  public isCollapse_est_vent_virt = true;
  public isCollapse_est_vent_contr = true;

  public isCollapsedt = true;
  public isCollapsedh = true;
  public isCollapsedg = true;
  public isCollapsedarrowa = false;
  public isCollapsedarrowb = false;

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  constructor(private loginService:LoginService,private navbarService:NavbarService,private router:Router,private modalService:NgbModal){
    this.subscription=this.navbarService.shownabvar.subscribe((value)=>{
      this.shownavbar=value;
      this.rol_id= localStorage.getItem('user');
      this.email = localStorage.getItem('email');
      if(this.rol_id==null){
        navbarService.hide();
      }
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  logout(){
    localStorage.removeItem('ObjCiudadano');
    localStorage.removeItem('login_usua_apellido');
    localStorage.removeItem('login_usua_nomb');

    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('email');
    localStorage.removeItem('cedula');
    localStorage.removeItem('nombres');
    localStorage.removeItem('apellidos');
    localStorage.removeItem('organizacion');
    localStorage.removeItem('cargo');

    this.router.navigate(['/login']);
    this.loginService.display();
    this.navbarService.hide();
  }

}
