import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BackendService } from 'src/app/services/backend.service';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';

@Component({
  selector: 'app-tramitlist',
  templateUrl: './tramitlist.component.html',
  styleUrls: ['./tramitlist.component.css']
})
export class TramitlistComponent {

  fstart:any;
  fend:any;
  limit:number=20;
  id_busquedaSelect:string='';
  name_busquedaSelect:string='';
  msgBusqueda:boolean = false;

  public formBuscar = {
    campo:""
  }

  public objetoBusqueda = {
    id:'',
    name:'',
    fstart:'',
    fend:'',
    cedula:''
  }

  shownavbar=true;
  public login_usua_nomb='';
  public login_usua_apellido='';

  menu=false;
  POSTS: any;
  page: number = 1;
  count: number = 0;
  tableSize: number = 20;
  tableSizes: any = [3, 6, 9, 12];
  dtTramite = new Array<any>();
  dtPdf = new Array();

  options: {id: string, nombre: string}[] = [
    { id: '1', nombre: 'No. de Registros' },
    { id: '2', nombre: 'No. de Tramite' },
    { id: '3', nombre: 'Cédula ciudadano' },
    { id: '4', nombre: 'Nombre ciudadano' }
  ];

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  public objUsuarioLogueado = {
    ciu_cedula:'',
    ciu_nombre:'',
    ciu_telefono:'',
    ciu_apellido:'',
    ciu_email:''
  }

  constructor(private backend: BackendService,private modalService:NgbModal){}

  ngOnInit(): void {
    if(localStorage.getItem('cedula')!==null){
      this.objetoBusqueda.id='0';
      this.objetoBusqueda.name='100';
      this.objetoBusqueda.fstart=this.fstart;
      this.objetoBusqueda.fend=this.fend;
      this.objetoBusqueda.cedula=String(localStorage.getItem('cedula'));
      this.fetchPosts(this.objetoBusqueda);
      this.login_usua_nomb=String(localStorage.getItem('nombres'));
      this.login_usua_apellido=String(localStorage.getItem('apellidos'));
      this.objUsuarioLogueado.ciu_cedula=String(localStorage.getItem('cedula'));
      this.objUsuarioLogueado.ciu_nombre=String(localStorage.getItem('nombres'))+' '+String(localStorage.getItem('apellidos'));
      this.objUsuarioLogueado.ciu_telefono=String(localStorage.getItem('telefono'));
      this.objUsuarioLogueado.ciu_email=String(localStorage.getItem('email'));
    }else{
      this.showModalError('La Cédula ha expirado!');
    }
  }

  fetchPosts(objetoBusqueda:any): void {
    this.backend.getTramitesFull(objetoBusqueda).subscribe((response:any) => {
        this.POSTS = response.list;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  onSelectChange(value: any) {
    this.name_busquedaSelect='';
    //this.POSTS=[];
  }

  onTableDataChange(event: any) {
    this.page = event;
    this.fetchPosts(this.objetoBusqueda);
  }

  mostrarPDF(arrpdf:string):void{
    var cadena_iz=arrpdf.replace('[','');
    var cadena_de=cadena_iz.replace(']','');
    var cadena_ce=cadena_de.replace(/['"]+/g, '');
    this.dtPdf=cadena_ce.split(',');
    this.menu=true;
  }

  buscarNOM_CED_TRAMI():void {
    this.POSTS=[];
    this.fstart=null;
    this.fend=null;
    this.objetoBusqueda.id=this.id_busquedaSelect;
    this.objetoBusqueda.name=this.name_busquedaSelect;
    this.objetoBusqueda.fstart='null';
    this.objetoBusqueda.fend='null';
    if(this.id_busquedaSelect=='1' || this.id_busquedaSelect=='2' || this.id_busquedaSelect=='3' || this.id_busquedaSelect=='4'){
      this.backend.getTramitesFull(this.objetoBusqueda).subscribe((response:any) => {
        if(response.status){
          this.msgBusqueda=false;
          this.POSTS = response.list;
        }else{
          this.POSTS=[];
          this.id_busquedaSelect='';
          this.name_busquedaSelect='';
          this.msgBusqueda=true;
        }
      });
    }
  }

  buscarDate():void{
    this.POSTS=[];
    this.id_busquedaSelect='';
    this.name_busquedaSelect='';
    this.objetoBusqueda.id='10';
    this.objetoBusqueda.name='x';
    this.objetoBusqueda.fstart=this.formatDate(this.fstart);
    this.objetoBusqueda.fend=this.formatDate(this.fend);
    this.backend.getTramitesFull(this.objetoBusqueda).subscribe((response:any) => {
      if(response.status){
        this.msgBusqueda=false;
        this.POSTS = response.list;
      }else{
        this.msgBusqueda=true;
        this.POSTS=[];
      }
    });
  }

  closeButtom():void {
    this.msgBusqueda=false;
  }

  ticketPDFDashboard(post:any): void{
    this.backend.public_tblb_org_migra_usuarios_by_Cedula(post.origen_cedul).subscribe((response:any) => {
      if(response.status){
        const objetoCiudadano = {
          tipo:'Trámite',
          idExpediente:post.codigo_documento,
          usua_sumilla:response.migra_usuario.usua_nomb+' '+response.migra_usuario.usua_apellido,
          idTramite:post.codigo_tramite,
          nomTramite:post.origen_form_asunto,
          nomCiudadano:post.origen_nombres,
          fechaIngresoTramite:post.origen_fecha_creado,
          horaIngresoTramite:post.hora_ingreso
        }
        this.backend.downloadPDFTramiteTicket(objetoCiudadano);
      }
    });
  }

  sendMailPDFDashboard(post:any): void{
    if(post.origen_ciud_email!="") {
        const objetoCiudadano = {
          tipo:'Trámite',
          idExpediente:post.codigo_documento,
          usua_sumilla:'this.objUsuarioLogueado.usua_sumilla',
          idTramite:post.codigo_tramite,
          nomTramite:post.origen_form_asunto,
          nomCiudadano:post.origen_nombres,
          fechaIngresoTramite:post.origen_fecha_creado,
          horaIngresoTramite:post.hora_ingreso,
          correo:post.origen_ciud_email
        }
        this.backend.sendEmailTramite_to_Ciudadano(objetoCiudadano).subscribe((response:any) => {
          if(response.status){
            this.showModal('El email:'+response.email+',se ha enviado hacia el Ciudadano');
          } else {
            this.showModalError('El email:'+response.email+', no se ha enviado hacia el Ciudadano');
          }
        });
    }else {
      this.showModalError('El ciudadano debe tener un email!');
    }
  }

  /*
  @HostListener('keypress', ['$event'])
  onKeyPress(event: KeyboardEvent) {
    if (event.key==='Enter') {
      if(this.limit<=500){
        this.fetchPosts(this.id_busquedaSelect,this.name_busquedaSelect);
        event.preventDefault();
        const button = event.target as HTMLButtonElement;
        button.click();
      } else {
        this.showModalError('Debe agregar un valor inferior a 500');
      }
    }
  }*/

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  formatDate(date: any): string {
    const year = date.year;
    const month = date.month < 10 ? `0${date.month}` : date.month;
    const day = date.day < 10 ? `0${date.day}` : date.day;
    return `${year}-${month}-${day}`;
  }

 }
