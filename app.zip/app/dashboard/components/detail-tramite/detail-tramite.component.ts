import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BackendService } from 'src/app/services/backend.service';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';

@Component({
  selector: 'app-detail-tramite',
  templateUrl: './detail-tramite.component.html',
  styleUrls: ['./detail-tramite.component.css']
})
export class DetailTramiteComponent {

  cad:string = '';
  arrayPdf= new Array();
  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  constructor(private router:ActivatedRoute,private backend:BackendService,private ngxService: NgxUiLoaderService,private modalService:NgbModal) { }

  ngOnInit(): void {
    this.ngxService.start();
    const ruta:any = this.router.snapshot.params;
    this.backend.getTramitesFilesListPDFById(ruta.tramite,ruta.documento).subscribe((data:any)=>{
      if(data.status){
        this.arrayPdf=data.listFiles
      }else{
        this.showModalError("Error al cargar los archivos PDF, consultar al administrador del Sitio");
      }
    });

    this.ngxService.stop();
  }

  formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0)
      return '0 MB';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const mb = bytes / Math.pow(k, 2);
    return `${parseFloat(mb.toFixed(dm))} MB`;
  }

  downloadPDFFile(pdfFileObject:any):void{
    this.ngxService.start();
    this.backend.downloadPDFBypathfileAdmin(pdfFileObject);
    this.ngxService.stop();
  }

  showPDFFile(pdfFileObject:any):void{
    this.ngxService.start();
    this.backend.showPDFBypathfileAdmin(pdfFileObject);
    this.ngxService.stop();
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

}
