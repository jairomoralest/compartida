import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TramitlistComponent } from './components/tramitlist/tramitlist.component';
import { ExternoGuard } from '../guard/externo.guard';
import { DetailTramiteComponent } from './components/detail-tramite/detail-tramite.component';

const routes: Routes = [

  {
    path:'detaiTramite/:tramite/:documento',
    component :DetailTramiteComponent,
    canActivate:[ExternoGuard]
  },
  {
    path:'dashboard',
    component :TramitlistComponent,
    canActivate:[ExternoGuard]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
