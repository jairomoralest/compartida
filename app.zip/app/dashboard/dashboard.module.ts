import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { TramitlistComponent } from './components/tramitlist/tramitlist.component';
import { FormsModule } from '@angular/forms';           // ngForm OK
import { NgxPaginationModule } from 'ngx-pagination';   // pagination
import { NgSelectModule } from '@ng-select/ng-select';  // select OK
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { DetailTramiteComponent } from './components/detail-tramite/detail-tramite.component';

@NgModule({
  declarations: [
    TramitlistComponent,
    DetailTramiteComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    FormsModule,
    NgxPaginationModule,
    NgSelectModule,
    NgbDatepickerModule
  ]
})
export class DashboardModule { }
