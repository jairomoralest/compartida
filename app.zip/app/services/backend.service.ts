import { Injectable } from '@angular/core';

import {  HttpClient, HttpEvent, HttpHeaders, HttpRequest }  from '@angular/common/http'
import { Observable, throwError } from 'rxjs';
import  { saveAs } from 'file-saver';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DialogComponent } from '../utilities/components/dialog/dialog.component';
import { DialogErrorComponent } from '../utilities/components/dialog-error/dialog-error.component';


@Injectable({
  providedIn: 'root'
})
export class BackendService {

  private apiBaseUrl ='http://172.16.7.23:81/api';    // PRO
  //private apiBaseUrl ='http://127.0.0.1:8000/api';    // DEV

  private apiBaseUrlWEBSERVICE_ORACLE ='http://172.16.3.50/sip_gd/BG/externo/oracle_ws_h.php';    // PRO
  //private apiBaseUrlWEBSERVICE_ORACLE ='http://localhost/WEBSERVICES/oracle_ws_h.php';            // DEV

  //private timesession=5;  5 minutos
  //private timesession=10;

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  constructor(private http:HttpClient,private modalService:NgbModal) {}

  /**********************************************************************************************************************/
  /************************************************* A D M I N I S T R A D O R  *****************************************/
  /**********************************************************************************************************************/

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  /*timeExitSession(){
    return this.timesession;
  }*/

  signup(data:any){
    return this.http.post(this.apiBaseUrl+'/signup',data);
  }

  registerciudadano(data:any){
    return this.http.post(this.apiBaseUrl+'/registerciudadano',data);
  }
  /*
  recoverPassword(data:any){
    return this.http.post(this.apiBaseUrl+'/recoverPassword',data);
  }*/

  login(data:any){
    return this.http.post(this.apiBaseUrl+'/login',data);
  }

  emaillogin(data:any){
    return this.http.post(this.apiBaseUrl+'/emaillogin',data);
  }

  logout(){
    localStorage.removeItem('token');
  }

  listciudadano(): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+'/listciudadano');
  }

  listuseractive(): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+'/listuseractive');
  }

  delete(id: number){
    return this.http.delete<any>(this.apiBaseUrl+`/deleteuser/${id}`);
  }

  getUserById(id:number): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/getUserById/${id}`);
  }

  getuserbyemail(email:string): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/getuserbyemail/${email}`);
  }

  checkemail(form:any){
    return this.http.post(this.apiBaseUrl+'/checkemail',form);
  }

  passwordChange(form:any){
    return this.http.post(this.apiBaseUrl+'/passwordChange',form);
  }

  updateuser(person: any) {
    return this.http.post(this.apiBaseUrl+'/updateuser',person);
  }

  updateUserState(person: any) {
    return this.http.post(this.apiBaseUrl+'/updateUserState',person);
  }

  public uploadfilevalidate(file:File[],data:any) {
    const vectortxt = [];
    let formParams = new FormData();
    for(let i=0; i<file.length; i++){
      vectortxt.push(file[i].name);
      formParams.append('fname'+i, file[i]);
    }
    formParams.append('id', data.id);
    formParams.append('nombres', data.nombres);
    formParams.append('apellidos', data.apellidos);
    formParams.append('cedula', data.cedula);
    formParams.append('telefono', data.telefono);
    formParams.append('organizacion', data.organizacion);
    formParams.append('cargo', data.cargo);
    formParams.append('dimension', String(file.length));

    return this.http.post(this.apiBaseUrl+'/uploadfilevalidate', formParams);
  }

  getUserFilesListPDFById(id:string) {
    return this.http.get<any[]>(this.apiBaseUrl+`/getUserFilesListPDFById/${id}`);
  }


  downloadPDFBypathfileAdmin(pdfObject:any) {
    const mediaType = 'application/pdf';
    const apiUrl = `${this.apiBaseUrl}/downloadPDFBypathfileAdmin`;
    return this.http.post(apiUrl, pdfObject, { responseType: 'blob' }).subscribe(
      (response:any) => {
        if(response.size>0){
          const blob = new Blob([response], { type: mediaType });
          const fileName = `${pdfObject.name}.pdf`;
          saveAs(blob, fileName);
        }else{
          this.showModalError('Error al descargar el archivo del Origen, Reportar el erroe hacia el Administrador');
        }
      },
      (error) => {
        throwError(error);
        console.error(error);
      }
    );
  }

  showPDFBypathfileAdmin(pdfObject:any) {
    const mediaType = 'application/pdf';
    const apiUrl = `${this.apiBaseUrl}/downloadPDFBypathfileAdmin`;
    return this.http.post(apiUrl, pdfObject, { responseType: 'blob' }).subscribe(
      (response:any) => {
        if(response.size>0){
          const blob = new Blob([response], { type: mediaType });
          const fileURL = URL.createObjectURL(blob);
          window.open(fileURL, '_blank');
        }else{
          this.showModalError('Error al descargar el archivo del Origen, Reportar el erroe hacia el Administrador');
        }
      },
      (error) => {
        throwError(error);
        console.error(error);
      }
    );
  }

  getuserById_(ciu_codigo: number){
    return this.http.get<any[]>(this.apiBaseUrl+`/getuserbyId/${ciu_codigo}`);
  }

  downloadPDF(nombres:string,cedula:string,telefono:string,email:string) {
    var mediaType = 'application/pdf';
    return this.http.post(this.apiBaseUrl+'/downloadPDF/'+nombres+'/'+cedula+'/'+telefono+'/'+email, {location: "documento_habilitante.pdf"}, { responseType: 'blob' }).subscribe(
        (response) => {
            var blob = new Blob([response], { type: mediaType });
            saveAs(blob, 'documento_habilitante.pdf');
        },
        e => { throwError(e);
        }
    );
  }

  liststate(): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+'/liststate');
  }

  getUserRol(email:any){
    return this.http.get(this.apiBaseUrl+`/getuserol/${email}`);
  }

  getRols(){
    return this.http.get<any>(this.apiBaseUrl+'/listAllRoles');
  }

  /**********************************************************************************************************************/
  /****************************************************** T R A M I T E  ************************************************/
  /**********************************************************************************************************************/

  downloadFormularioPDF(pdfObject:any) {
    const mediaType = 'application/pdf';
    const apiUrl = `${this.apiBaseUrl}/downloadFormularioPDF`;
    return this.http.post(apiUrl, pdfObject, { responseType: 'blob' }).subscribe(
      (response:any) => {
        if(response.size>0){
          const blob = new Blob([response], { type: mediaType });
          const fileName = `data.pdf`;
          saveAs(blob, fileName);
          //this.showModal('Debe completar el formulario y anexarlo.');
        }else{
          this.showModalError('Error al descargar el archivo de origen, Reportar el erroe hacia el Administrador');
        }
      },
      (error) => {
        this.showModalError('Error al descargar el archivo del origen, Reportar el erroe hacia el Administrador');
        throwError(error);
        console.error(error);
      }
    );
  }

  downloadPDFFormularioUnicoJSON(objetoPerson: any) {
    const mediaType = 'application/pdf';
    const url = `${this.apiBaseUrl}/downloadPDFFormularioUnicoJSON`;
    const jsonData = JSON.stringify(objetoPerson);
    this.http.post(url, jsonData, { responseType: 'blob' }).subscribe(
        (response: Blob) => {
            const blob = new Blob([response], { type: mediaType });
            saveAs(blob, 'docformulariounico.pdf');
        },
        (error) => {
            console.error('Error downloading PDF:', error);
        }
    );
  }

   // Para tamites y documentos.
   downloadPDFTramiteTicket(objCiudadano: any) {
    var mediaType = 'application/pdf';
    const jsonData = JSON.stringify(objCiudadano);
    return this.http.post(this.apiBaseUrl+'/downloadPDFTramiteTicketJSON', jsonData, { responseType: 'blob' }).subscribe(
      (response) => {
        const blob = new Blob([response], { type: mediaType });
        //saveAs(blob, 'ticket.pdf');
        const fileURL = URL.createObjectURL(blob);
        window.open(fileURL, '_blank');
      },
      (error) => {
          console.error('Error:', error);
          return throwError(error);
      }
    );
  }

  sendEmailTramite_to_Ciudadano(objCiudadano: any) {
    return this.http.post(this.apiBaseUrl+'/sendEmailTramite_to_Ciudadano',objCiudadano);
  }

  create_tramite_without_files(objTramite:any,file:File[]){
    let formParams = new FormData();
    formParams.append('objTecnicoResponsable', JSON.stringify(objTramite.objTecnicoResponsable));
    formParams.append('objProceso', JSON.stringify(objTramite.objProceso));
    formParams.append('idDepartamento', objTramite.idDepartamento);
    formParams.append('objCiudadano', JSON.stringify(objTramite.objCiudadano));
    formParams.append('fieldAsunto', objTramite.fieldAsunto);
    formParams.append('fieldNumpaginas', objTramite.fieldNumpaginas);
    formParams.append('selectedRequisitosCombo', JSON.stringify(objTramite.selectedRequisitosCombo));
    formParams.append('selectedReqCmblength', objTramite.selectedReqCmblength);
    return this.http.post(this.apiBaseUrl+'/create_tramite_without_files',formParams);
  }

  create_tramite_anexo(objArbol:any,file:File[]){
    const vectortxt = [];
    let formParams = new FormData();
    for(let i=0; i<file.length; i++){
      vectortxt.push(file[i].name);
      formParams.append('fname'+i, file[i]);
    }
    formParams.append('objArbol', JSON.stringify(objArbol));
    formParams.append('dimension', String(file.length));
    formParams.append('vectortxt', JSON.stringify(vectortxt));
    return this.http.post(this.apiBaseUrl+'/create_tramite_anexo',formParams);
  }

  listtramite(): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+'/listtramite');
  }

  public uploadfiletramite(file:File[],data:any) {
    const vectortxt = [];
    let formParams = new FormData();
    for(let i=0; i<file.length; i++){
      vectortxt.push(file[i].name);
      formParams.append('fname'+i, file[i]);
    }
    formParams.append('cedula', data.cedula);
    formParams.append('asunto', data.asunto);
    formParams.append('year', data.fecha.year);
    formParams.append('month', data.fecha.month);
    formParams.append('day', data.fecha.day);
    formParams.append('tipo_tramite', data.tipo_tramite);
    formParams.append('estado', data.estado);
    formParams.append('dimension', String(file.length));
    formParams.append('vectortxt', JSON.stringify(vectortxt));
    return this.http.post(this.apiBaseUrl+'/uploadtramites', formParams);
  }

  getTramiteById(id: number){
    return this.http.get<any[]>(this.apiBaseUrl+`/gettramitebyId/${id}`);
  }

  loadPDFTramite(pathfile:string) {
    var mediaType = 'application/pdf';
    return this.http.post(this.apiBaseUrl+'/downloadPDFBypathfiletramite/'+pathfile, {location: pathfile}, { responseType: 'blob' }).subscribe(
        (response) => {
            var blob = new Blob([response], { type: mediaType });
            saveAs(blob, pathfile);
        },
        e => {
          throwError(e);
          console.log(e);
        }
    );
  }

  /*WEB SERVICE*/

  public uploadfiletramiteWEBSERVICE(file:File[],data:any) {
    const vectortxt = [];
    let formParams = new FormData();
    for(let i=0; i<file.length; i++){
      vectortxt.push(file[i].name);
      formParams.append('fname'+i, file[i]);
    }
    formParams.append('cedula', data.cedula);
    formParams.append('tipo_tramite', data.tipo_tramite);
    formParams.append('dimension', String(file.length));
    formParams.append('vectoradjunto', JSON.stringify(vectortxt));
    return this.http.post(this.apiBaseUrl+'/uploadtramitesWEBSERVICE', formParams);
  }


  /**********************************************************************************************************************/
  /***************************************** O R A C L E  -  O C I  - W E B   S E R V I C E *****************************/
  /**********************************************************************************************************************/

  getInfoFromOCIgetByCiu(ciu:any) {
    const url = `${this.apiBaseUrlWEBSERVICE_ORACLE}?ciu=${ciu}`;
    return this.http.get<any>(url);
  }

  getInfoFromOCIgetByRuc(ruc:any) {
    const url = `${this.apiBaseUrlWEBSERVICE_ORACLE}?ruc=${ruc}`;
    return this.http.get<any>(url);
  }

  getInfoFromOCIgetByApellido(apellido:any) {
    const url = `${this.apiBaseUrlWEBSERVICE_ORACLE}?apellido=${apellido}`;
    return this.http.get<any>(url);
  }

  //cedcony eliminar
  create_public_ciudadano_OCI(data: any){
    const url = `${this.apiBaseUrlWEBSERVICE_ORACLE}?ins_nom=${data.nom}&ins_ape=${data.ape}&ins_dir=${data.dir}&ins_fcreformat=${data.fcreformat}&ins_disca=${data.disca}&ins_resi=${data.resi}&ins_correo=${data.correo}&ins_nombre=${data.nombre}&ins_ruc=${data.ruc}&ins_telefono=${data.telefono}&tipo=1`;
    return this.http.get<any>(url);
  }

  update_ciudadano_OCI(data: any){
    const url = `${this.apiBaseUrlWEBSERVICE_ORACLE}?upd_codigo=${data.codigo}&upd_nom=${data.nom}&upd_ape=${data.ape}&upd_dir=${data.dir}&upd_correo=${data.correo}&upd_nombre=${data.nombre}&upd_ruc=${data.ruc}&upd_tel=${data.telefono}&tipo=2`;
    return this.http.get<any>(url);
  }

  /**********************************************************************************************************************/
  /***************************************************** C A T A L O G O S  *********************************************/
  /**********************************************************************************************************************/

  public_tblb_org_migra_usuarios_by_Cedula(cedula:any): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/tblb_org_migra_usuarios_by_Cedula/${cedula}`);
  }

  public_tblb_org_departamento(tipo:string): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/tblb_org_departamentoByTipo/${tipo}`);
  }


  public_tblu_ciudadano_Login_ByCedula(cedula: string): Observable<any[]>{
    console.log('cedula BACK:'+cedula);
    return this.http.get<any[]>(this.apiBaseUrl+`/tblu_ciudadano_Login_ByCedula/${cedula}`);
  }

  /*
  public_tblb_org_migra_usuarios_by_Cedula(cedula:any): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/tblb_org_migra_usuarios_by_Cedula/${cedula}`);
  }*/

  public_tblb_org_departamento_Objecto(id:any): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/tblb_org_departamentoById_Objeto/${id}`);
  }

  public_tble_proc_procesoByID(id: number): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/tble_proc_procesoByID/${id}`);
  }

  public_tblh_cr_catalogo_requisitos_byproceso(id: number): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/public_tblh_cr_catalogo_requisitos_byproceso/${id}`);
  }

  public_tblu_migra_usuarios_tecnicos_bycod_depenid(cod_depenid:number): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/public_tblu_migra_usuarios_tecnicos_bycod_depenid/${cod_depenid}`);
  }

  select_obj_tecnico_responsable(id: number): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/select_obj_tecnico_responsable/${id}`);
  }

  /**********************************************************************************************************************/
  /*************************************************** D O C U M E N T O ************************************************/
  /**********************************************************************************************************************/
  create_documento_without_files(objTramite:any){
    let formParams = new FormData();
    formParams.append('idcuadroClasificacion',objTramite.idcuadroClasificacion);
    formParams.append('objTecnico',JSON.stringify(objTramite.objTecnico));
    formParams.append('selectedIDTipo',objTramite.selectedIDTipo);
    formParams.append('selectedIDFisico',objTramite.selectedIDFisico);
    formParams.append('selectedIDTecnico',objTramite.selectedIDTecnico);
    formParams.append('formfillDocumento',JSON.stringify(objTramite.formfillDocumento));
    formParams.append('formSelCiudadano',JSON.stringify(objTramite.formSelCiudadano));
    formParams.append('nombreFuente',objTramite.nombreFuente);
    return this.http.post(this.apiBaseUrl+'/create_documento_without_files',formParams);
  }

  create_documento_anexo(objArbol:any,file:File[]){
    const vectortxt = [];
    let formParams = new FormData();
    for(let i=0; i<file.length; i++){
      vectortxt.push(file[i].name);
      formParams.append('fname'+i, file[i]);
    }
    formParams.append('objArbol', JSON.stringify(objArbol));
    formParams.append('dimension', String(file.length));
    formParams.append('vectortxt', JSON.stringify(vectortxt));
    return this.http.post(this.apiBaseUrl+'/create_documento_anexo',formParams);
  }

  getList_tble_recep_doc_tecnico_migraByID(tecnico_codigo:any): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/getList_tble_recep_doc_tecnico_migraByID/${tecnico_codigo}`);
  }

  getList_tble_bg_exp_cuadro_clasificacion1(): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/select_list_cuadro_clasficiacion/`);
  }

  getList_tble_recep_doc_fisico(fisico: string): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/select_list_recep_doc_fisico/${fisico}`);
  }

  getList_tble_recep_doc_tipo(tipo: string): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/select_list_recep_doc_tipo/${tipo}`);
  }

  getList_tble_recep_doc_tecnico_migra(): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/select_list_recep_doc_tecnico_migra/`);
  }

  public_tblu_migra_usuarios_Login_ByCedula(cedula: string): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/tblu_migra_usuarios_Login_ByCedula/${cedula}`);
  }

  getInfoFromPOSTGRESgetByApellido(apellido:any) {
    return this.http.get<any[]>(this.apiBaseUrl+`/getInfoFromPOSTGRESgetByApellido/${apellido}`);
  }

  getInfoFromPOSTGRESgetByCedula(usua_cedula:any) {
    return this.http.get<any[]>(this.apiBaseUrl+`/getInfoFromPOSTGRESgetByCedula/${usua_cedula}`);
  }

  getInfoFromPOSTGRESgetByCod_ciudadano_ServiceShared(ciu_codigo:any) {
    return this.http.get<any[]>(this.apiBaseUrl+`/getInfoFromPOSTGRESgetByCod_ciudadano_ServiceShared/${ciu_codigo}`);
  }

  getInfoFromPOSTG_ByCiu_codigo(ciu_codigo:any) {
    return this.http.get<any[]>(this.apiBaseUrl+`/getInfoFromPOSTG_ByCiu_codigo/${ciu_codigo}`);
  }

  downloadPDFDesmaterializadoJSON(objetoPerson: any) {
    const mediaType = 'application/pdf';
    const url = `${this.apiBaseUrl}/downloadPDFDesmaterializadoJSON`;
    const jsonData = JSON.stringify(objetoPerson);
    this.http.post(url, jsonData, { responseType: 'blob' }).subscribe(
        (response: Blob) => {
            const blob = new Blob([response], { type: mediaType });
            saveAs(blob, 'docdesmaterializado.pdf');
        },
        (error) => {
            console.error('Error downloading PDF:', error);
        }
    );
  }

  /**********************************************************************************************************************/
  /****************** O R A C L E  -  O C I  - W E B   S E R V I C E  -  C L A V E   C A T A S T R A L  *****************/
  /**********************************************************************************************************************/

  //getByCC_URBANO
  getInfoFromOCIgetByClaveCat_Urbano(curbano:any){
    const url = `${this.apiBaseUrlWEBSERVICE_ORACLE}?curbano=${curbano}`;
    return this.http.get<any>(url);
  }

  getInfoFromOCIgetByClaveCat_Rural(crural:any){
    const url = `${this.apiBaseUrlWEBSERVICE_ORACLE}?crural=${crural}`;
    return this.http.get<any>(url);
  }

  /**********************************************************************************************************************/
  /**************************************************** D A S H B O A R D ***********************************************/
  /**********************************************************************************************************************/

  getTramitesFilesListPDFById(tramite: string, documento: string) {
    return this.http.get<any[]>(`${this.apiBaseUrl}/getTramitesFilesListPDFById/${tramite}/${documento}`);
  }

  getTramitesFull(objBusqueda:any) {
    let formParams = new FormData();
    formParams.append('id', objBusqueda.id);
    formParams.append('name', objBusqueda.name);
    formParams.append('fstart', objBusqueda.fstart);
    formParams.append('fend', objBusqueda.fend);
    formParams.append('cedula', objBusqueda.cedula);
    return this.http.post<any[]>(`${this.apiBaseUrl}/getTramitesFull`, formParams);
  }

  downloadPDFFormularioUnicoJSONDashboard(objetoPerson: any) {
    const mediaType = 'application/pdf';
    const url = `${this.apiBaseUrl}/downloadPDFFormularioUnicoJSONDashboard`;
    const jsonData = JSON.stringify(objetoPerson);
    this.http.post(url, jsonData, { responseType: 'blob' }).subscribe(
        (response: Blob) => {
            const blob = new Blob([response], { type: mediaType });
            saveAs(blob, 'docformulariounico.pdf');
        },
        (error) => {
            console.error('Error downloading PDF:', error);
        }
    );
  }

  /**********************************************************************************************************************/
  /********************************************** C O N T R A T I S T A  ************************************************/
  /**********************************************************************************************************************/
  create_obra_contratista(objContratista:any,file:File[]){
    const vectortxt = [];
    let formParams = new FormData();
    for(let i=0; i<file.length; i++){
      vectortxt.push(file[i].name);
      formParams.append('fname'+i, file[i]);
    }
    //formParams.append('objUsuarioLogueado', JSON.stringify(objContratista.objUsuarioLogueado));
    formParams.append('objCategoria', JSON.stringify(objContratista.objCategoria));
    formParams.append('objTecnico', JSON.stringify(objContratista.objTecnico));
    formParams.append('formfillDocumento',JSON.stringify(objContratista.formfillDocumento));
    formParams.append('selectedIDTecnico', objContratista.selectedIDTecnico);
    formParams.append('selectedIDObra', objContratista.selectedIDObra);
    formParams.append('objContratista', JSON.stringify(objContratista.objContratista));
    formParams.append('objFiscalizador', JSON.stringify(objContratista.objFiscalizador));
    formParams.append('formSelContratista', JSON.stringify(objContratista.formSelContratista));
    formParams.append('dimension', String(file.length));
    formParams.append('vectortxt', JSON.stringify(vectortxt));
    return this.http.post(this.apiBaseUrl+'/create_obra_contratista',formParams);
  }

  getList_tble_bg_obra(cedula:any): Observable<any[]>{
    console.log(cedula);
    return this.http.get<any[]>(this.apiBaseUrl+`/getList_tble_bg_obra/${cedula}`);
  }

  getObj_Obra_by_Id_adminFiscalContrato(id_adminContrato:any) {
    return this.http.get<any[]>(this.apiBaseUrl+`/getObj_Obra_by_Id_adminFiscalContrato/${id_adminContrato}`);
  }
  getList_tble_categoria(): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/getList_tble_categoria/`);
  }

  getList_tble_bg_expendiende_ByID(id_cat:any): Observable<any[]>{
    return this.http.get<any[]>(this.apiBaseUrl+`/getList_tble_bg_expendiende_ByID/${id_cat}`);
  }


}
