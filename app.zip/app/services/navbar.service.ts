import { Injectable, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NavbarService implements OnInit{

  shownabvar : BehaviorSubject<boolean>;

  constructor(){
    this.shownabvar= new BehaviorSubject(true);
  }

  ngOnInit(): void {
    if(localStorage.getItem('user')===null){
      this.shownabvar.next(false);
    }else {
      this.shownabvar.next(true);
    }
  }

  hide() {
    this.shownabvar.next(false);
  }

  display() {
    this.shownabvar.next(true);
  }

}
