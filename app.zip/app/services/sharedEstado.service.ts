import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class sharedEstado {

  private firstDataESTADO = new BehaviorSubject<any>(null);
  estadoData$ = this.firstDataESTADO.asObservable();

  constructor() {}

  sendFirstDataCIU(estado: any) {
    this.firstDataESTADO.next(estado);
  }

}
