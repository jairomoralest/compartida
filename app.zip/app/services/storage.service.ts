import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { delay, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

    constructor(private router: Router) {}

    setItem(key: string, value: any, expiryTimeInMinutes: number): void {
      // descomentar para habilitar tiempo de vida de las sesiones
      //const now = new Date();
      //const expiryTime = new Date(now.getTime() + expiryTimeInMinutes * 60000).getTime();
      localStorage.setItem(key, value);
      //this.startExpiryTimer(key, expiryTimeInMinutes * 60000);
    }

    getItem(key: string): any {
      const itemStr = localStorage.getItem(key);
      if (!itemStr) {
        return null;
      }
      const item = JSON.parse(itemStr);
      const now = new Date();
      if (now.getTime() > item.expiry) {
        localStorage.removeItem(key);
        return null;
      }
      return item.value;
    }

    removeItem(key: string): void {
      localStorage.removeItem(key);
    }

    clear(): void {
      localStorage.clear();
    }

    private startExpiryTimer(key: string, delayTime: number): void {
      of(null)
        .pipe(
          delay(delayTime),
          tap(() => {
            console.log(`Expiring key: ${key}`);
            this.removeItem(key);
            //this.router.navigate(['/login']);
            //localStorage.removeItem('user');

          })
        )
        .subscribe();
    }
  }
