import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShareAService {

  private firstDataESTADO = new BehaviorSubject<any>(null);
  estadoData$ = this.firstDataESTADO.asObservable();

  constructor() {}

  sendFirstDataESTADO(estado: any) {
    this.firstDataESTADO.next(estado);
  }

}
