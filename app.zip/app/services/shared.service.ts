import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  private firstDataCIU = new BehaviorSubject<any>(null);

  ciuData$ = this.firstDataCIU.asObservable();
  constructor() {}

  sendFirstDataCIU(ciu: any) {
    this.firstDataCIU.next(ciu);
  }

}
