import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private shownabvarSubject: BehaviorSubject<boolean>;

  constructor() {
    console.log('LoginService constructor');
    this.shownabvarSubject = new BehaviorSubject(true);
  }

  hide(): void {
    this.shownabvarSubject.next(false);
  }

  display(): void {
    this.shownabvarSubject.next(true);
  }

  get shownabvar(): Observable<boolean> {
    return this.shownabvarSubject.asObservable();
  }
}
