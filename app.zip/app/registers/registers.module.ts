import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegistersRoutingModule } from './registers-routing.module';
import { RegisterComponent } from './components/register/register.component';
import { ValidateComponent } from './components/validate/validate.component';
import { FormsModule } from '@angular/forms';           // ngModule
import { NgSelectModule } from '@ng-select/ng-select';
import { RecoverComponent } from './components/recover/recover.component';
import { FormpasswordrecoverComponent } from './components/formpasswordrecover/formpasswordrecover.component';  // select OK

@NgModule({
  declarations: [
    RegisterComponent,
    ValidateComponent,
    RecoverComponent,
    FormpasswordrecoverComponent
  ],
  imports: [
    CommonModule,
    RegistersRoutingModule,
    NgSelectModule,
    FormsModule
  ]
})
export class RegistersModule { }
