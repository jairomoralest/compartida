import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ValidateComponent } from './components/validate/validate.component';
import { RegisterComponent } from './components/register/register.component';
import { RecoverComponent } from './components/recover/recover.component';
import { FormpasswordrecoverComponent } from './components/formpasswordrecover/formpasswordrecover.component';

const routes: Routes = [
  {
    path:'personedit/:email',
    component :ValidateComponent
  },
  {
    path:'registerpublic',
    component :RegisterComponent
  },
  {
    path:'datarecover',
    component :RecoverComponent
  },
  {
    path:'formpasswordrecover/:email',
    component :FormpasswordrecoverComponent
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RegistersRoutingModule { }
