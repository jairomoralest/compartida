import { Component } from '@angular/core';
import { BackendService } from '../../../services/backend.service';
import { ActivatedRoute, Router } from '@angular/router';
import { interval, firstValueFrom, subscribeOn, throwError, Observable } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ElementRef, ViewChild } from '@angular/core';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { NavbarService } from 'src/app/services/navbar.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-validate',
  templateUrl: './validate.component.html',
  styleUrls: ['./validate.component.css']
})
export class ValidateComponent {

  public form = {
    id:null,
    nombres:null,
    apellidos:null,
    cedula:null,
    telefono:null,
    email:null,
    organizacion:null,
    cargo:null
  }

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  filestramite:any;
  public error:any=[];
  datosPersona : any = {};
  duplicateFiles: string[] = [];
  public loadfileShow:boolean = false;
  public messagePDFAlertA:boolean = false;
  public messagePDFAlertB:boolean = false;

  /* FILES */
  filescertificado:any;
  @ViewChild('fileInputRefCertificado') fileInputRef!: ElementRef<HTMLInputElement>;
  @ViewChild('fileInputRefCertificadoced') fileInputRefc!: ElementRef<HTMLInputElement>;
  sumFileSize=0;
  public myArrayFilescertificado:any = [];

  constructor(private loginService:LoginService,private navbarService:NavbarService,private backend:BackendService,private route: ActivatedRoute,private router: Router,private modalService:NgbModal,private ngxService: NgxUiLoaderService) {  }

  async ngOnInit() {

    if(localStorage.getItem('token')){
      this.navbarService.hide();
    }

    this.ngxService.start();
    var ruta:any = this.route.snapshot.params;
    if(ruta.email){
      this.datosPersona = await firstValueFrom(this.backend.getuserbyemail(ruta.email));
      if(this.datosPersona!=null){
        if(this.datosPersona.estado=='REGISTRADO'){
          this.ngxService.stop();
          this.form.id = this.datosPersona.id;
          this.form.nombres = this.datosPersona.nombres;
          this.form.apellidos = this.datosPersona.apellidos;
          this.form.cedula = this.datosPersona.cedula;
          this.form.telefono = this.datosPersona.telefono;
          this.form.email = this.datosPersona.email;
        }else{
          this.ngxService.stop();
          this.showModalError('Se ha detectado que el estado actual no está REGISTRADO. Por favor, notifique al administrador para que tome las medidas necesarias.');
          this.router.navigate(['/login']);
        }
      }
    }
    this.ngxService.stop();
  }

  isNumeric(value: any): boolean {
    return !isNaN(parseFloat(value)) && isFinite(value);
  }

  isText(value: any): boolean {
    return typeof value === 'string';
  }

  submitUsaerValidate(){
    this.ngxService.start();
    this.sumFileSize=0;
    for(var i=0; i<this.myArrayFilescertificado.length;i++) {
      this.sumFileSize+=parseFloat(this.myArrayFilescertificado[i].size);
    }
    const valorMB=parseFloat(this.formatBytes(this.sumFileSize, 2));
    if(valorMB <= 10) {
      const objetoPerson = {
        id:this.form.id,
        nombres:this.form.nombres,
        apellidos:this.form.apellidos,
        cedula:this.form.cedula,
        telefono:this.form.telefono,
        email:this.form.email,
        organizacion:this.form.organizacion,
        cargo:this.form.cargo
      }
      const json = JSON.stringify(objetoPerson);
      const parsed = JSON.parse(json);
      if(this.myArrayFilescertificado.length > 0){
        this.backend.uploadfilevalidate(this.myArrayFilescertificado,parsed).subscribe((resp:any) => {
          this.ngxService.stop();
          if(resp.state){
            this.showModal('Su cuenta será activada después de que el administrador valide sus datos.');
            this.router.navigate(['/login']);
          } else {
            this.ngxService.stop();
            this.showModalError('Error al cargar los anexos.');
          }
        }, (err:any) => {
          this.ngxService.stop();
        });
      }else{
        this.ngxService.stop();
        this.showModalError('Descargar y Anexar Acuerdo en Formato PDF.');
      }
    }else{
      this.ngxService.stop();
      this.showModalError('Los archivos adjuntos exceden el límite de 10 MB. Por favor, reduzca su tamaño y vuelva a intentarlo.');
    }
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0)
      return '0 MB';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const mb = bytes / Math.pow(k, 2);
    return `${parseFloat(mb.toFixed(dm))} MB`;
  }

  public async downloadPDF() {
    const objetoPerson = {
      id:this.form.id,
      nombres:this.form.nombres+' '+this.form.apellidos,
      cedula:this.form.cedula,
      telefono:this.form.telefono,
      email:this.form.email,
    }
    const json = JSON.stringify(objetoPerson);
    const parsed = JSON.parse(json);
    if(parsed.nombres!=null && parsed.cedula!=null && parsed.telefono!=null){
      this.ngxService.start();
      this.backend.downloadPDF(parsed.nombres,parsed.cedula,parsed.telefono,parsed.email);
      this.ngxService.stop();
      this.loadfileShow=true;
      this.messagePDFAlertA=true;
      this.messagePDFAlertB=true;
    }else{
      this.showModalError('Debe ingresar los datos del formulario.');
    }
  }

  closemessagePDFShowA():void{
    this.messagePDFAlertA=false;
  }

  closemessagePDFShowB():void{
    this.messagePDFAlertB=false;
  }

  closeForm(){
    this.showModalError('Usted debe generar un documento en formato PDF y subir el archivo.');
    this.router.navigate(['login']);
  }

  handleError(error:any){
    this.error= error.error.errors;
  }

  keyPressNumbers(event:any) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  onDropCertificado(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    const files = event.dataTransfer?.files;
    if (files) {
      this.handleFilesCertificado(files);
    }
  }

  onDragOverCertificado(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
  }

  handleFilesCertificado(files: FileList | null) {
    if (files) {
      this.duplicateFiles = [];
      for (let i = 0; i < files.length; i++) {
        var file = files[i];
        var fileNameExists = this.myArrayFilescertificado.some((f: any) => f.name === file.name);
        if (fileNameExists) {
          this.duplicateFiles.push(file.name);
        } else if (file.type === 'application/pdf' && file.size <= 10485760) {
          this.myArrayFilescertificado.push(file);
        } else {
          this.modalinfo.body='Debe cargar un documento en formato PDF, con un peso inferior a 10 MB.';
          const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
          modalRef.componentInstance.modalinfo = this.modalinfo;
        }
      }
      if (this.duplicateFiles.length === 1) {
        this.modalinfo.body=`El archivo ${this.duplicateFiles.join(', ')}, ya se ha ingresado.`;
        const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
        modalRef.componentInstance.modalinfo = this.modalinfo;
      }else if (this.duplicateFiles.length > 1) {
        this.modalinfo.body=`Existen archivos que ya se han ingresado: ${this.duplicateFiles.join(', ')}`;
        const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
        modalRef.componentInstance.modalinfo = this.modalinfo;
      }
    }
  }

  onFilesSelectedCertificado(event: Event): void {
    this.filestramite = (event.target as HTMLInputElement).files;
    if (this.filestramite) {
      this.duplicateFiles = [];
      for (let i = 0; i < this.filestramite.length; i++) {
        var file = this.filestramite[i];
        var fileNameExists = this.myArrayFilescertificado.some((f: any) => f.name === file.name);
        if (fileNameExists) {
          this.duplicateFiles.push(file.name);
        } else if (file.type === 'application/pdf' && file.size <= 10485760) {
          this.myArrayFilescertificado.push(file);
        } else {
          this.modalinfo.body='Debe cargar un documento en formato PDF, con un peso inferior a 10 MB';
          const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
          modalRef.componentInstance.modalinfo = this.modalinfo;
        }
      }
      if (this.duplicateFiles.length === 1) {
        this.modalinfo.body=`El archivo ${this.duplicateFiles.join(', ')}, ya se ha ingresado.`
        const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
        modalRef.componentInstance.modalinfo = this.modalinfo;
      }else if (this.duplicateFiles.length > 1) {
        this.modalinfo.body=`Existen archivos que ya se han ingresado: ${this.duplicateFiles.join(', ')}`;
        const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
        modalRef.componentInstance.modalinfo = this.modalinfo;
      }
    }
  }

  deleteFileCertificado(index: number) {
    this.myArrayFilescertificado.splice(index, 1);
  }

}
