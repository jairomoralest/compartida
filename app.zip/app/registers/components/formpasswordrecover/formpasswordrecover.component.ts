import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BackendService } from 'src/app/services/backend.service';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';
import { interval, firstValueFrom, subscribeOn, throwError, Observable } from 'rxjs';
import { LoginService } from 'src/app/services/login.service';
import { NavbarService } from 'src/app/services/navbar.service';

@Component({
  selector: 'app-formpasswordrecover',
  templateUrl: './formpasswordrecover.component.html',
  styleUrls: ['./formpasswordrecover.component.css']
})
export class FormpasswordrecoverComponent {

  public form  = {
    id:null,
    email:null,
    password:null,
    newpassword:null
  }

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  public error:any=[];
  showPassword = false;
  datosPersona : any = {};
  showPasswordBack = false;
  passwordPattern = '(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#.,*¡!()?$%^&+=]).{8,}';

  constructor(private loginService:LoginService,private navbarService:NavbarService,private route: ActivatedRoute,private backend:BackendService,private router:Router,private modalService:NgbModal,private ngxService: NgxUiLoaderService) { }

  async ngOnInit() {

    if(localStorage.getItem('token')){
      this.navbarService.hide();
    }

    var ruta:any = this.route.snapshot.params;
    if(ruta.email){
      this.datosPersona = await firstValueFrom(this.backend.getuserbyemail(ruta.email));
      if(this.datosPersona!=null){
        if(this.datosPersona.estado=='ACTIVO'){
          this.ngxService.stop();
          this.form.id = this.datosPersona.id;
          this.form.email = this.datosPersona.email;
          console.log(this.form)
        }else{
          this.showModalError("Su cuenta debe estar activada, para continuar con el proceso");
          this.ngxService.stop();
          this.router.navigate(['/login']);
        }
      }
    }
  }

  passwordChange(){
    this.ngxService.start();
    if(this.form.password===this.form.newpassword){
       this.ngxService.stop();
      this.backend.passwordChange(this.form).subscribe((resp:any) => {
        if(resp.state){
          this.ngxService.stop();
          this.router.navigate(['login']);
          this.showModal("Su contraseña ha sido restablecida exitosamente. Use su nueva contraseña para iniciar sesión. Si necesita ayuda adicional, no dude en contactar con el soporte.");
        }else{
          this.ngxService.stop();
          this.showModalError("Error al cambiar la contraseña, comuníquese con el administrador del Sitio");
          this.router.navigate(['login']);
        }
      }, (err:any) => {
        console.log(err);
        this.ngxService.stop();
      });


    }else{
      this.ngxService.stop();
      this.showModalError("Las contraseñas no coinciden. Por favor, verifique que ambas contraseñas sean iguales.");
    }
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }


  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }



  togglePasswordVisibilityBack() {
    this.showPasswordBack = !this.showPasswordBack;
  }


}

