import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BackendService } from 'src/app/services/backend.service';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';
import { LoginService } from 'src/app/services/login.service';
import { NavbarService } from 'src/app/services/navbar.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  public form  = {
    cedula:null,
    email:null,
    password:null
  }

  showPassword = false;
  passwordPattern = '(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#.,*¡!()?$%^&+=]).{8,}';

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  public error:any=[];
  constructor(private loginService:LoginService,private navbarService:NavbarService,private backend:BackendService,private router:Router,private modalService:NgbModal,private ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    if(localStorage.getItem('token')){
      this.navbarService.hide();
    }
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }
  submitRegister(){
    this.ngxService.start();
    this.backend.registerciudadano(this.form).subscribe((resp:any) => {
      console.log(resp);
      if(resp.status){
        this.ngxService.stop();
        this.modalinfo.body=resp.message;
        const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
        modalRef.componentInstance.modalinfo = this.modalinfo;
        this.router.navigate(['login']);
      }else{
        this.ngxService.stop();
        this.modalinfo.body=resp.message;
        const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
        modalRef.componentInstance.modalinfo = this.modalinfo;
      }
    }, (err:any) => {
      this.ngxService.stop();
    });
  }

  keyPressNumbers(event:any) {
    var charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  isNumeric(value: any): boolean {
    return !isNaN(parseFloat(value)) && isFinite(value);
  }


  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }


}
