import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BackendService } from 'src/app/services/backend.service';
import { LoginService } from 'src/app/services/login.service';
import { NavbarService } from 'src/app/services/navbar.service';
import { DialogErrorComponent } from 'src/app/utilities/components/dialog-error/dialog-error.component';
import { DialogComponent } from 'src/app/utilities/components/dialog/dialog.component';

@Component({
  selector: 'app-recover',
  templateUrl: './recover.component.html',
  styleUrls: ['./recover.component.css']
})
export class RecoverComponent {

  public form  = {
    email:null
  }

  public modalinfo = {
    head: 'Mensaje informativo',
    body: ''
  }

  public error:any=[];
  constructor(private loginService:LoginService,private navbarService:NavbarService,private backend:BackendService,private router:Router,private modalService:NgbModal,private ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    if(localStorage.getItem('token')){
      this.navbarService.hide();
    }
  }

  recoverPassword(){
    this.ngxService.start();
    this.backend.checkemail(this.form).subscribe((resp:any) => {
      if(resp.state){
        this.ngxService.stop();
        this.router.navigate(['login']);
        this.showModal("Se ha enviado un enlace para la recuperación de contraseña a su correo electrónico "+resp.objUser.email);
      }else{
        this.ngxService.stop();
        this.showModalError("El correo electrónico no existe. Por favor, revise y envíe el mensaje nuevamente.");
      }
    }, (err:any) => {
      console.log(err);
      this.ngxService.stop();
    });
  }

  showModal(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

  showModalError(body:string):void{
    this.modalinfo.body=body;
    const modalRef = this.modalService.open(DialogErrorComponent, { size: 'md', backdrop: 'static' });
    modalRef.componentInstance.modalinfo = this.modalinfo;
  }

}

